//
//  MapView.swift
//  Dworcownik
//
//  Created by stud on 28/11/2025.
//

import SwiftUI
import MapKit
import SwiftData

struct MapView: View {
    @Query(sort: \Station.name) private var allStations: [Station]
    
    @State private var cameraPosition: MapCameraPosition = .userLocation(fallback: .automatic)
    @Namespace private var mapScope
    
    var body: some View {
        NavigationStack {
            Map(position: $cameraPosition, scope: mapScope) {
                UserAnnotation()
                ForEach (allStations) { station in
                    Annotation(
                        "",
                        coordinate: CLLocationCoordinate2D(
                            latitude: station.latitude,
                            longitude: station.longitude
                        )
                    )
                    {
                        MapAnnotationTile(station: station)
                    }
                }
            }
            .mapControls{
                MapScaleView()
            }
            .mapStyle(.standard(pointsOfInterest: .excludingAll))
            .navigationTitle("Stacje na mapie")
            .toolbarTitleDisplayMode(.inlineLarge)
            .safeAreaInset(edge: .bottom, alignment: .trailing) {
                VStack {
                    MapCompass(scope: mapScope)
                    MapUserLocationButton(scope: mapScope)
                }
                    .buttonBorderShape(.circle)
                    .padding()
            }
            .mapScope(mapScope)
        }
    }
}

#Preview {
    MapView().modelContainer(Station.preview)
}
