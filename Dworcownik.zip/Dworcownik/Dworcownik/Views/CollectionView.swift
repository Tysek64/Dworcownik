//
//  CollectionView.swift
//  Dworcownik
//
//  Created by stud on 28/11/2025.
//

import SwiftUI
import SwiftData

struct CollectionView: View {
    @State private var test: Int = 0
    
    @Query(sort: \Event.startDate, order: .reverse) private var allEvents: [Event]
    @Query(sort: [SortDescriptor(\Line.lineOperator?.name), SortDescriptor(\Line.name)]) private var allLines: [Line]
    @Query(sort: \LineOperator.name) private var allOperators: [LineOperator]
    @Query(sort: \Station.name) private var allStations: [Station]
    
    @State private var filterShown: Bool = false
    
    @State private var operatorsFilter: [LineOperator:(Bool,Bool)] = [:]
    @State private var regionsFilter: [Region:(Bool,Bool)] = [:]
    @State private var generalFilter: [Filters:(Bool,Bool)] = [:]
    
    @State private var searchText: String = ""
    
    var body: some View {
        NavigationStack {
            VStack {
                Picker("", selection: $test) {
                    Text("Linie").tag(0);
                    Text("Stacje").tag(1);
                    Text("Pieczątki").tag(2);
                }
                .pickerStyle(.segmented)
                .padding(.horizontal)
                ScrollView {
                switch test {
                case 0:
                        LinesCollection(
                            allLines: allLines.filter({ $0.passesCriteria(searchText: searchText) && ($0.lineOperator == nil || operatorsFilter[$0.lineOperator!]?.0 ?? true) }),
                            allOperators: allOperators,
                            allEvents: allEvents.filter({ $0.passesCriteria(searchText: searchText) }),
                            generalFilter: generalFilter,
                        )
                case 1:
                        StationsCollection(
                            allStations: allStations.filter({ $0.passesCriteria(searchText: searchText) && ($0.region == nil || regionsFilter[$0.region ?? .DS]?.0 ?? true) }),
                            generalFilter: generalFilter
                        )
                case 2:
                        StampsCollection(
                            allStations: allStations.filter({ $0.region == nil || regionsFilter[$0.region ?? .DS]?.0 ?? true }),
                            criteria: searchText,
                            generalFilter: generalFilter
                        )
                default:
                    ContentUnavailableView("niema", systemImage: "paperplane")
                }
                }
                .padding()
                .scrollBounceBehavior(.basedOnSize)
            }
            .navigationTitle("Moja kolekcja")
            .toolbarTitleDisplayMode(.inlineLarge)
            .toolbar {
                DefaultToolbarItem(kind: .search)
                ToolbarItem {
                    Button() {
                        filterShown = true
                    }
                    label: {
                        if (
                            regionsFilter.values.reduce(
                                false,
                                { total, current in
                                    total || (current.0 != current.1)
                                }
                            ) ||
                            operatorsFilter.values.reduce(
                                false,
                                { total, current in
                                    total || (current.0 != current.1)
                                }
                            ) ||
                            generalFilter.values.reduce(
                                false,
                                { total, current in
                                    total || (current.0 != current.1)
                                }
                            )
                        ) {
                            Image(systemName: "slider.horizontal.3")
                                .displayBadge
                        } else {
                            Image(systemName: "slider.horizontal.3")
                        }
                    }
                }
            }
            .sheet(isPresented: $filterShown) {
                NavigationStack {
                    CollectionFilter(regionsFilter: $regionsFilter, operatorsFilter: $operatorsFilter, generalFilter: $generalFilter)
                        .toolbar {
                            ToolbarItem(placement: .cancellationAction) {
                                Button () {
                                    for key in regionsFilter.keys {
                                        regionsFilter[key]!.0 = regionsFilter[key]!.1
                                    }
                                    for key in operatorsFilter.keys {
                                        operatorsFilter[key]!.0 = operatorsFilter[key]!.1
                                    }
                                    for key in generalFilter.keys {
                                        generalFilter[key]!.0 = generalFilter[key]!.1
                                    }
                                }
                                label: {
                                    Image(systemName: "arrow.trianglehead.counterclockwise")
                                }
                            }
                            ToolbarItem() {
                                Button () {
                                    filterShown = false
                                }
                                label: {
                                    Image(systemName: "checkmark")
                                }
                                .buttonStyle(.glassProminent)
                            }
                        }
                }
            }
        }
        .searchable(text: $searchText, placement: .toolbar, prompt: "Wyszukaj...")
        .searchPresentationToolbarBehavior(.avoidHidingContent)
        .onAppear {
            if regionsFilter.isEmpty {
                for region in Region.allCases {
                    regionsFilter[region] = (true,true)
                }
            }
            
            if operatorsFilter.isEmpty {
                for lineOperator in allOperators {
                    operatorsFilter[lineOperator] = (true,true)
                }
            }
            
            if generalFilter.isEmpty {
                generalFilter[.FAV] = (true,true)
                generalFilter[.EVT] = (true,true)
                generalFilter[.NCL] = (false,false)
            }
        }
    }
}

#Preview {
    CollectionView().modelContainer(Station.preview)
}
