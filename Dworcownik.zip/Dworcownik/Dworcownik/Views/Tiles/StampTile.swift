//
//  StampTile.swift
//  Dworcownik
//
//  Created by Krzysztof Żałobka on 29/12/2025.
//

import SwiftUI

struct StampTile: View {
    @State private var infoShown: Bool = false
    var stampToShow: Stamp
    private var mainStamp: some View {
        return ZStack {
            Circle()
                .fill(.background)
                .glassEffect(in: .circle)
            stampToShow.imageAsset
                .resizable()
                .scaledToFit()
                .padding()
        }
    }
    var body: some View {
        Button () {
            infoShown = true
        }
        label: {
            mainStamp
        }
        .buttonStyle(.plain)
        .sheet(isPresented: $infoShown) {
            NavigationStack {
                VStack {
                    mainStamp
                    Text("Pieczątka ze stacji")
                        .padding(.top)
                    Text("\(stampToShow.station?.name ?? "")")
                        .font(.largeTitle)
                    Text("Zdobyta \(stampToShow.collectedTime?.dateOnly ?? "")")
                        .font(.footnote)
                }
                    .padding()
                    .navigationTitle("Pieczątka")
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .cancellationAction) {
                            Button () {
                                infoShown = false
                            }
                            label: {
                                Image(systemName: "xmark")
                            }
                        }
                        ToolbarItem {
                            ShareLink(
                                item: stampToShow.imageAsset,
                                subject: Text("Zdobyta przeze mnie pieczątka"),
                                message: Text("Mogę się pochwalić zdobyciem pieczątki na stacji \(stampToShow.station?.name ?? "") w dniu \(stampToShow.collectedTime?.dateOnly ?? Date.now.dateOnly)!"),
                                preview: SharePreview("Pieczątka ze stacji \(stampToShow.station?.name ?? "")", image: stampToShow.imageAsset)
                            )
                                .buttonStyle(.glassProminent)
                        }
                    }
            }
        }
    }
}

#Preview {
    StampTile(stampToShow: Stamp(station: Station(name: "test", builtYear: 2000), difficulty: 2))
}
