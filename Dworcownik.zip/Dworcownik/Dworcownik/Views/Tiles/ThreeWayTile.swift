//
//  ThreeWayTile.swift
//  Dworcownik
//
//  Created by stud on 05/12/2025.
//

import SwiftUI

struct ThreeWayTile: View {
    var first: String = "test"
    var second: String = "test"
    var third: String = "test"
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 34)
                .fill(.background)
                .glassEffect(in: .rect(cornerRadius: 34));
            VStack {
                Text(first);
                Spacer();
                Text(second)
                    .font(Font.custom("SF Pro", size: 64));
                Spacer();
                Text(third)
                    .font(Font.largeTitle);
            }.padding([.top, .bottom])
        }
    }
}

#Preview {
    ThreeWayTile()
}
