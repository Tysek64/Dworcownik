//
//  BigTime.swift
//  Dworcownik
//
//  Created by stud on 13/11/2025.
//

import SwiftUI
import SwiftData

struct BigTile: View {
    @State private var infoShown: Bool = false
    var eventToShow: Event
    var body: some View {
        NavigationLink {
            EventInfoView(eventToShow: eventToShow)
        }
        label: {
            ZStack {
                RoundedRectangle(cornerRadius: 34)
                    .fill(.background)
                    .glassEffect(in: .rect(cornerRadius: 34));
                VStack(alignment: .leading) {
                    ZStack(alignment: .topLeading) {
                        UnevenRoundedRectangle(topLeadingRadius: 34, topTrailingRadius: 34)
                            .fill(Color.accentColor)
                            .overlay {
                                eventToShow.imageAsset
                                    .clipAndFill
                                    .clipShape(.rect(uniformTopCorners: .fixed(34), uniformBottomCorners: .fixed(0)))
                            }
                        Button() {
                            infoShown = true
                        }
                        label: {
                            ZStack {
                                Circle()
                                    .rotation(.degrees(-90))
                                    .trim(from: CGFloat(eventToShow.numberVisited)/CGFloat(eventToShow.numberTotal), to: 1)
                                    .stroke(.primary, lineWidth: 3)
                                    .frame(width: 36, height: 36);
                                Circle()
                                    .rotation(.degrees(-90))
                                    .trim(from: 0, to: CGFloat(eventToShow.numberVisited)/CGFloat(eventToShow.numberTotal))
                                    .stroke(Color.accentColor, lineWidth: 3)
                                    .frame(width: 36, height: 36);
                                Text("\(eventToShow.numberVisited)/\(eventToShow.numberTotal)")
                                    .font(Font.caption)
                            }
                        }
                        .buttonBorderShape(.circle)
                        .buttonStyle(.glass)
                        .frame(width: 48, height: 48)
                        .padding(11)
                    };
                    Text("\(eventToShow.startDate.dateOnly) ~ \(eventToShow.endDate.dateOnly)")
                        .font(Font.footnote)
                        .padding(.horizontal)
                    Text(eventToShow.name)
                        .fontWeight(.heavy)
                        .padding(.horizontal)
                    Text(eventToShow.info)
                        .lineLimit(2, reservesSpace: true)
                        .padding(.horizontal);
                }
                .padding(.bottom)
            }
            .aspectRatio(1.175, contentMode: .fit)
            .padding([.horizontal], 22)
            .containerRelativeFrame(.horizontal, count: 1, spacing: 0)
            .sheet(isPresented: $infoShown) {
                NavigationStack {
                    List {
                        if eventToShow.numberVisited < eventToShow.numberTotal {
                            Section (header: Text("Nieodwiedzone stacje")) {
                                ForEach (eventToShow.stations?.filter({ $0.numberVisited == 0}) ?? []) { station in
                                    NavigationLink(
                                        station.name,
                                        destination: StationInfoView(stationToShow: station),
                                    )
                                }
                            }
                        }
                        if eventToShow.numberVisited > 0 {
                            Section (header: Text("Odwiedzone stacje")) {
                                ForEach (eventToShow.stations?.filter({ $0.numberVisited > 0}) ?? []) { station in
                                    NavigationLink(
                                        station.name,
                                        destination: StationInfoView(stationToShow: station),
                                    )
                                }
                            }
                        }
                    }
                    .navigationTitle("\(eventToShow.name)")
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .cancellationAction) {
                            Button() {
                                infoShown = false
                            }
                            label: {
                                Image(systemName: "xmark")
                            }
                        }
                    }
                }
            }
        }
        .buttonStyle(.plain)
    }
}

#Preview {
    BigTile(eventToShow: Event(name: "Nazwa wydarzenia", info: "Opis wydarzenia opis wydarzenia opis wydarzenia opis wydarzenia opis wydarzenia opis wydarzenia opis wydarzenia", imagePath: "ev2"))
}
