//
//  MapAnnotationTile.swift
//  Dworcownik
//
//  Created by Krzysztof Żałobka on 05/01/2026.
//

import SwiftUI

struct MapAnnotationTile: View {
    var station: Station
    
    var body: some View {
        NavigationLink (destination: StationInfoView(stationToShow: station)) {
            VStack {
                Image(systemName: "tram.circle")
                Text("(\(station.numberVisited))")
                    .frame(width: 32)
                    .font(.footnote)
            }
            .foregroundStyle(station.numberScanned > 0 ? .blue : (station.numberVisited > 0 ? .primary : .secondary))
            .padding()
            .glassEffect(in: .rect(cornerRadius: 34))
        }
    }
}

#Preview {
    MapAnnotationTile(station: Station(name: "test"))
}
