//
//  SmallTile.swift
//  Dworcownik
//
//  Created by stud on 21/11/2025.
//

import SwiftUI

enum SLEUnion {
    case station (Station)
    case event (Event)
    case line (Line)
}
struct CollectionTile: View {
    var toShow: SLEUnion
    @State private var test: Bool = false
    var body: some View {
        let showCheckmark =
        switch toShow {
        case .station(let station):
            station.numberScanned > 0
        case .event(let event):
            event.numberVisited == event.numberTotal
        case .line(let line):
            line.numberVisited == line.numberTotal
        }
        ZStack {
            RoundedRectangle(cornerRadius: 34)
                .fill(.background)
                .glassEffect(in: .rect(cornerRadius: 34));
            VStack {
                ZStack(alignment: .topLeading) {
                    UnevenRoundedRectangle(topLeadingRadius: 34, topTrailingRadius: 34)
                        .fill(Color.accentColor)
                        .overlay {
                            switch toShow {
                            case .station(let station):
                                station.imageAsset
                                    .clipAndFill
                                    .clipShape(.rect(uniformTopCorners: .fixed(34), uniformBottomCorners: .fixed(0)))
                            case .event(let event):
                                event.imageAsset
                                    .clipAndFill
                                    .clipShape(.rect(uniformTopCorners: .fixed(34), uniformBottomCorners: .fixed(0)))
                            case .line(let line):
                                line.imageAsset
                                    .clipAndFill
                                    .clipShape(.rect(uniformTopCorners: .fixed(34), uniformBottomCorners: .fixed(0)))
                            }
                        }
                    if showCheckmark {
                        Image(systemName: "checkmark.seal")
                            .foregroundColor(.accentColor)
                            .frame(width: 36, height: 36)
                            .glassEffect(in: .circle)
                            .padding(16)
                    }
                }
                switch toShow {
                case .station(let station):
                    Text("\(station.name)")
                        .lineHeight(.multiple(factor: 2))
                        .fontWeight(.heavy)
                        .lineLimit(1);
                    Text("Odwiedzono \(station.numberVisited) raz\(station.numberVisited == 1 ? "" : "y")")
                        .font(.footnote)
                        .foregroundColor(station.numberVisited > 0 ? .accentColor : .secondary);
                case .event(let event):
                    Text("\(event.startDate.dateOnly) ~ \(event.endDate.dateOnly)")
                        .font(.footnote)
                        .lineLimit(1);
                    Text("\(event.name)")
                        .fontWeight(.heavy)
                        .lineLimit(1);
                    Text("\(event.numberVisited)/\(event.numberTotal)")
                        .font(.footnote)
                        .foregroundColor(event.numberVisited > 0 ? .accentColor : .secondary);
                case .line(let line):
                    Text("\(line.lineOperator?.name ?? "")")
                        .font(.footnote)
                        .lineLimit(1);
                    Text("\(line.name)")
                        .fontWeight(.heavy)
                        .lineLimit(1);
                    Text("\(line.numberVisited)/\(line.numberTotal)")
                        .font(.footnote)
                        .foregroundColor(line.numberVisited > 0 ? .accentColor : .secondary);
                }
            }
        }
        .aspectRatio(0.9, contentMode: .fit)
    }
}

#Preview {
    CollectionTile(toShow: SLEUnion.station(Station(name: "stacja", builtYear: 2000, imagePath: "os")))
}
