//
//  SmallTile.swift
//  Dworcownik
//
//  Created by stud on 21/11/2025.
//

import SwiftUI

enum SLEUnion {
    case station (Station)
    case event (Event)
    case line (Line)
}
struct CollectionTile: View {
    var toShow: SLEUnion
    
    var body: some View {
        let showCheckmark =
        switch toShow {
        case .station(let station):
            station.isCompleted
        case .event(let event):
            event.isCompleted
        case .line(let line):
            line.isCompleted
        }
        NavigationLink {
            switch toShow {
            case .station(let station):
                StationInfoView(stationToShow: station)
            case .event(let event):
                EventInfoView(eventToShow: event)
            case .line(let line):
                LineInfoView(lineToShow: line)
            }
        } label: {
            ZStack {
                RoundedRectangle(cornerRadius: 34)
                    .fill(.background)
                    .glassEffect(in: .rect(cornerRadius: 34));
                VStack {
                    ZStack(alignment: .topLeading) {
                        UnevenRoundedRectangle(topLeadingRadius: 34, topTrailingRadius: 34)
                            .fill(Color.accentColor)
                            .overlay {
                                switch toShow {
                                case .station(let station):
                                    station.imageAsset
                                        .clipAndFill
                                        .blur(radius: station.isLocked ? 7 : 0, opaque: true)
                                        .overlay {
                                            if station.isLocked {
                                                Image(systemName: "lock")
                                                    .resizable()
                                                    .scaledToFit()
                                                    .padding()
                                            }
                                        }
                                        .clipShape(.rect(uniformTopCorners: .fixed(34), uniformBottomCorners: .fixed(0)))
                                case .event(let event):
                                    event.imageAsset
                                        .clipAndFill
                                        .clipShape(.rect(uniformTopCorners: .fixed(34), uniformBottomCorners: .fixed(0)))
                                case .line(let line):
                                    line.imageAsset
                                        .clipAndFill
                                        .clipShape(.rect(uniformTopCorners: .fixed(34), uniformBottomCorners: .fixed(0)))
                                }
                            }
                        if showCheckmark {
                            Image(systemName: "checkmark.seal")
                                .foregroundColor(.accentColor)
                                .frame(width: 36, height: 36)
                                .glassEffect(in: .circle)
                                .padding(16)
                        }
                    }
                    switch toShow {
                    case .station(let station):
                        Text("\(station.name)")
                            .lineHeight(.multiple(factor: 2))
                            .fontWeight(.heavy)
                            .lineLimit(1);
                        Text("Odwiedzono \(station.numberVisited) raz\(station.numberVisited == 1 ? "" : "y")")
                            .font(.footnote)
                            .foregroundColor(station.isLocked ? .secondary : .accentColor);
                    case .event(let event):
                        Text("\(event.startDate.dateOnly) ~ \(event.endDate.dateOnly)")
                            .font(.footnote)
                            .lineLimit(1);
                        Text("\(event.name)")
                            .fontWeight(.heavy)
                            .lineLimit(1);
                        Text("\(event.numberVisited)/\(event.numberTotal)")
                            .font(.footnote)
                            .foregroundColor(event.isLocked ? .secondary : .accentColor);
                    case .line(let line):
                        Text("\(line.lineOperator?.name ?? "")")
                            .font(.footnote)
                            .lineLimit(1);
                        Text("\(line.name)")
                            .fontWeight(.heavy)
                            .lineLimit(1);
                        Text("\(line.numberVisited)/\(line.numberTotal)")
                            .font(.footnote)
                            .foregroundColor(line.isLocked ? .secondary : .accentColor);
                    }
                }
            }
            .aspectRatio(0.9, contentMode: .fit)
        }
        .buttonStyle(.plain)
    }
}

#Preview {
    CollectionTile(toShow: SLEUnion.station(Station(name: "stacja", builtYear: 2000, imagePath: "os")))
}
