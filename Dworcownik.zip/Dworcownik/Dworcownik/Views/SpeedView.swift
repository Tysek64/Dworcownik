//
//  SpeedView.swift
//  Dworcownik
//
//  Created by stud on 28/11/2025.
//

import SwiftUI
import SwiftData
import MapKit

struct SpeedView: View {
    @EnvironmentObject private var locationManager: LocationManager
    @Query private var allStations: [Station]
    var body: some View {
        let sortedStations = allStations.sorted(
            by:
                { (a: Station, b: Station) -> Bool in
                    a.calculateDistance(userLocation: locationManager.currentLocation) <
                        b.calculateDistance(userLocation: locationManager.currentLocation)
                }
        )
        NavigationStack {
            VStack {
                Text("Prędkościomierz")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .cornerRadius(34)
                    .glassEffect(in: .rect(cornerRadius: 34))
                HStack {
                    ThreeWayTile(
                        first: "Obecna prędkość",
                        second: String(format: "%.1f", self.locationManager.currentSpeed),
                        third: "km/h"
                    );
                    ThreeWayTile(
                        first: "Maksymalna prędkość",
                        second: String(format: "%.1f", self.locationManager.maxSpeed),
                        third: "km/h"
                    );
                };
                Text("Najbliższe stacje")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .cornerRadius(34)
                    .glassEffect(in: .rect(cornerRadius: 34));
                HStack {
                    ThreeWayTile(
                        first: "\(sortedStations[0].name)",
                        second: String(format: "%.1f", sortedStations[0].calculateDistance(userLocation: locationManager.currentLocation)),
                        third: "km"
                    );
                    ThreeWayTile(
                        first: "\(sortedStations[1].name)",
                        second: String(format: "%.1f", sortedStations[1].calculateDistance(userLocation: locationManager.currentLocation)),
                        third: "km"
                    );
                }
            }
            .padding()
            .navigationTitle("W podróży")
            .toolbarTitleDisplayMode(.inlineLarge)
        }
    }
}

#Preview {
    SpeedView().modelContainer(Station.preview).environmentObject(LocationManager())
}
