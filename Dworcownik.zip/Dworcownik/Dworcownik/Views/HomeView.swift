//
//  HomeView.swift
//  Dworcownik
//
//  Created by stud on 28/11/2025.
//

import SwiftUI
import SwiftData

struct HomeView: View {
    @Environment(\.modelContext) private var context
    @Query(sort: \Event.startDate, order: .reverse) private var allEvents: [Event]
    @Query(sort: \LineOperator.name) private var allOperators: [LineOperator]
    @Query(sort: \Line.name) private var allLines: [Line]
    @Query(sort: \Line.addedDate) private var newLines: [Line]
    
    @State private var shownEventId: Int = 0
    @State private var scrollInitiatedInSV: Bool = false
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 11) {
                    Text("Obecne wydarzenia")
                        .sectionHeading
                        .padding(.horizontal)
                    if allEvents.isEmpty {
                        ContentUnavailableView("Brak wydarzeń", systemImage: "rectangle.on.rectangle.slash")
                            .containerRelativeFrame(.vertical, count: 2, spacing: 0);
                    } else {
                        VStack{
                            ScrollViewReader { value in
                                VStack {
                                    ScrollView(.horizontal, showsIndicators: false) {
                                        HStack(spacing:-33) {
                                            ForEach(Array(allEvents.enumerated()), id: \.offset) { (i, event) in
                                                BigTile(eventToShow: event)
                                                    .id(i)
                                            }
                                        }
                                        .scrollTargetLayout()
                                    }
                                    .scrollTargetBehavior(.viewAligned)
                                    .onScrollTargetVisibilityChange(idType: Int.self, { values in
                                        if !values.isEmpty {
                                            if values.first! != shownEventId {
                                                scrollInitiatedInSV = true
                                            }
                                            shownEventId = values.first!
                                        }
                                    })
                                    TabView(selection: $shownEventId) {
                                        ForEach(Array(allEvents.enumerated()), id: \.offset) { (i, event) in
                                            Text("")
                                                .tag(i)
                                        }
                                    }
                                    .tabViewStyle(.page(indexDisplayMode: .always))
                                    .onChange(of: shownEventId) { _, newValue in
                                        if !scrollInitiatedInSV {
                                            value.scrollTo(shownEventId)
                                        } else {
                                            scrollInitiatedInSV = false
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    Text("Nowo dodane linie")
                        .sectionHeading
                        .padding(.horizontal)
                    ScrollView(.horizontal) {
                        HStack(spacing:-16.5) {
                            ForEach(newLines) { line in
                                if line.addedDate > Calendar.current.date(byAdding: DateComponents(month: -1), to: Date.now)! {
                                    CollectionTile(toShow: SLEUnion.line(line))
                                        .padding(.trailing, 5.5)
                                        .padding(.leading, 22)
                                        .containerRelativeFrame(.horizontal, count: 2, spacing: 0)
                                        .padding(.trailing, line == newLines.last ? 16.5 : 0)
                                }
                            }
                        }
                        .scrollTargetLayout()
                    }
                    .scrollTargetBehavior(.viewAligned)
                    
                    ForEach(allOperators) { lineOperator in
                        let operatorName = lineOperator.name
                        let operatorLines = try! allLines.filter(#Predicate<Line> { line in
                            (line.lineOperator != nil) && (line.lineOperator!.name == operatorName)
                        })
                        if !operatorLines.isEmpty {
                            Text("\(lineOperator.name)")
                                .sectionHeading
                                .padding(.horizontal)
                            ScrollView(.horizontal) {
                                HStack(spacing:-16.5) {
                                    ForEach(operatorLines) { line in
                                        CollectionTile(toShow: SLEUnion.line(line))
                                            .padding(.trailing, 5.5)
                                            .padding(.leading, 22)
                                            .containerRelativeFrame(.horizontal, count: 2, spacing: 0)
                                            .padding(.trailing, line == operatorLines.last ? 16.5 : 0)
                                    }
                                }
                                .scrollTargetLayout()
                            }
                            .scrollTargetBehavior(.viewAligned)
                        }
                    }
                }
            }
            .navigationTitle("Dzień dobry!")
            .toolbarTitleDisplayMode(.inlineLarge)
        }
    }
}

#Preview {
    HomeView().modelContainer(Station.preview)
}
