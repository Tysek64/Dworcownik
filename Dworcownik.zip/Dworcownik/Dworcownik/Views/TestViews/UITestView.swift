//
//  UITestView.swift
//  Dworcownik
//
//  Created by Krzysztof Żałobka on 03/01/2026.
//

import SwiftUI

struct UITestView: View {
    var body: some View {
        Button () {
            
        }
        label: {
            Image(systemName: "xmark")
        }
        .buttonStyle(.glassProminent)
        .buttonBorderShape(.circle)
        .displayBadge
    }
}

#Preview {
    UITestView()
}
