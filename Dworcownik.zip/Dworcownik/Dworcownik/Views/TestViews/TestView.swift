//
//  TestView.swift
//  Dworcownik
//
//  Created by Krzysztof Żałobka on 29/12/2025.
//

import SwiftUI
import SwiftData

struct TestView: View {
    @Environment(\.modelContext) var modelContext: ModelContext
    @Query private var allStations: [Station]
    
    var body: some View {
        NavigationStack {
            VStack {
                ForEach(allStations) { station in
                    HStack {
                        Text("\(station.name)")
                        
                        Spacer()
                        
                        Button() {
                            station.addPass()
                            try? modelContext.save()
                        }
                        label: {
                            Image(systemName: "plus")
                        }
                        
                        Button() {
                            station.addStop(resetPasses: false)
                            try? modelContext.save()
                        }
                        label: {
                            Image(systemName: "plus")
                        }
                        
                        Button() {
                            station.addScan(resetStops: false)
                            try? modelContext.save()
                        }
                        label: {
                            Image(systemName: "plus")
                        }
                        
                        Button() {
                            station.isFavorite.toggle()
                            try? modelContext.save()
                        }
                        label: {
                            Image(systemName: station.isFavorite ? "heart.fill" : "heart")
                        }
                        Text("\(station.numberVisited)")
                    }
                    .padding()
                }
            }
            .toolbar {
                ToolbarItem(placement: .destructiveAction) {
                    Button () {
                        DBSeeder(context: modelContext, source: HardcodedDataSource()).nukeAndPopulate()
                    }
                    label: {
                        Image(systemName: "bolt.fill")
                    }
                }
            }
        }
    }
}

#Preview {
    TestView()
        .modelContainer(
            Station.preview
        )
}
