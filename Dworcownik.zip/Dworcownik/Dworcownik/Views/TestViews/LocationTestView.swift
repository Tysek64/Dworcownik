//
//  LocationTestView.swift
//  Dworcownik
//
//  Created by stud on 05/12/2025.
//

import SwiftUI
import MapKit
import CoreLocationUI

struct LocationTestView: View {
    @ObservedObject private var locationManager: LocationManager = LocationManager()
    
    var body: some View {

        ZStack {
            MapView()
                .mapControls{
                    MapUserLocationButton()
                };
            VStack {
                Text("\(self.locationManager.currentSpeed)")
                    .foregroundColor(Color.white)
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(10)
                Text("\(self.locationManager.maxSpeed)")
                    .foregroundColor(Color.white)
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(10)
            }
        }
    }
}

#Preview {
    LocationTestView()
}
