//
//  ScannerView.swift
//  Dworcownik
//
//  Created by Krzysztof Żałobka on 02/01/2026.
//

import Foundation
import SwiftUI
import CodeScanner
import AVFoundation
import SwiftData

struct ScannerView: View {
    @Environment(\.modelContext) var modelContext: ModelContext
    
    @State private var scanResult: String = ""
    @State private var scanSuccessful: Bool = false
    @State private var checkinShown: Bool = false
    
    var body: some View {
        NavigationStack {
            VStack {
                CodeScannerView(codeTypes: [.qr], completion: handleScan)
                    .aspectRatio(1, contentMode: .fit)
                    .cornerRadius(34)
                    .padding()
                    .navigationTitle("Zeskanj kod QR")
                Text(scanResult.hexed)
                Text("\(currentStation == nil ? "-" : currentStation!.name.hexed)")
            }
        }
        .sheet(isPresented: $checkinShown) {
            NavigationStack {
                VStack {
                    if scanSuccessful {
                        Text("Witamy w:")
                        Text("\(currentStation!.name)")
                            .font(.largeTitle)
                        Text("To Twój \(currentStation!.numberVisited). raz tutaj!")
                            .font(.footnote)
                    } else {
                        ContentUnavailableView("Błąd skanowania", systemImage: "mappin.slash", description: Text("Być może nie jesteś na stacji"))
                    }
                }
                .navigationTitle("Zeskanowano kod QR")
                .toolbarTitleDisplayMode(.inlineLarge)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button () {
                            checkinShown = false
                        }
                        label: {
                            Image(systemName: "xmark")
                        }
                    }
                }
            }
        }
    }
    
    func handleScan (result: Result<ScanResult, ScanError>) {
        switch result {
        case .success(let result):
            scanSuccessful = false
            scanResult = result.string
            if currentStation != nil && currentStation!.name == scanResult {
                scanSuccessful = true
                currentStation?.addScan(resetStops: currentStatus > 0)
                try? modelContext.save()
                currentStatus = 3
            }
            checkinShown = true
        case .failure(let error):
            print("Nie udało się \(error.localizedDescription) ):")
        }
    }
}
