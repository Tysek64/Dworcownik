//
//  CollectionSearchView.swift
//  Dworcownik
//
//  Created by Krzysztof Żałobka on 03/01/2026.
//

import SwiftUI
import SwiftData

struct CollectionSearchView: View {
    @State private var test: Int = 0
    
    @Query(sort: \Event.startDate, order: .reverse) private var allEvents: [Event]
    @Query(sort: [SortDescriptor(\Line.lineOperator?.name), SortDescriptor(\Line.name)]) private var allLines: [Line]
    @Query(sort: \Station.name) private var allStations: [Station]
    
    @State private var searchShown: Bool = false
    @State private var searchText: String = ""
    @State private var isSearching: Bool = false
    
    var body: some View {
        NavigationStack {
            VStack {
                /*
                 Picker("", selection: $test) {
                 Text("Linie").tag(0);
                 Text("Stacje").tag(1);
                 Text("Pieczątki").tag(2);
                 }
                 .pickerStyle(.segmented)
                 .padding(.horizontal)
                 */
                if isSearching {
                    ScrollView {
                        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())]) {
                            Section(
                                header:
                                    Text("Wydarzenia")
                                    .sectionHeading
                                    .leftAlign
                            ) {
                                ForEach(allEvents) { event in
                                    if event.name.contains(searchText) {
                                        NavigationLink(destination: EventInfoView(eventToShow: event)) {
                                            CollectionTile(toShow: SLEUnion.event(event))
                                        }
                                        .buttonStyle(.plain)
                                    }
                                }
                            }
                            Section(
                                header:
                                    Text("Linie")
                                    .sectionHeading
                                    .leftAlign
                            ) {
                                ForEach(allLines) { line in
                                    if line.name.contains(searchText) || line.lineOperator?.name.contains(searchText) ?? false {
                                        NavigationLink(destination: LineInfoView(lineToShow: line)) {
                                            CollectionTile(toShow: SLEUnion.line(line))
                                        }
                                        .buttonStyle(.plain)
                                    }
                                }
                            }
                            Section(
                                header:
                                    Text("Stacje")
                                    .sectionHeading
                                    .leftAlign
                            ) {
                                ForEach(allStations) { station in
                                    if station.name.contains(searchText) || station.region?.rawValue.contains(searchText) ?? false {
                                        NavigationLink(destination: StationInfoView(stationToShow: station)) {
                                            CollectionTile(toShow: SLEUnion.station(station))
                                        }
                                        .buttonStyle(.plain)
                                    }
                                }
                            }
                        }
                    }
                } else {
                    ContentUnavailableView("Wyszukaj coś", systemImage: "sparkle.magnifyingglass")
                }
            }
            .padding()
            .searchable(text: $searchText, isPresented: $isSearching, prompt: "Wyszukaj...")
            .searchSuggestions {
                let suggestions = ["Warszawa Wschodnia", "Linia 1", "PKP Intercity"]
                ForEach(suggestions, id: \.hash) { suggestion in
                    Text(suggestion).searchCompletion(suggestion)
                }
            }
            .navigationTitle("Wyszukaj")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    CollectionSearchView()
}
