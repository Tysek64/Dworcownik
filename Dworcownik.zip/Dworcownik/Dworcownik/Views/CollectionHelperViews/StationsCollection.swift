//
//  StationsCollection.swift
//  Dworcownik
//
//  Created by Krzysztof Żałobka on 03/01/2026.
//

import SwiftUI

struct StationsCollection: View {
    var allStations: [Station]
    
    var generalFilter: [Filters:(Bool,Bool)]

    var body: some View {
        let showFavs = generalFilter[.FAV]?.0 ?? true
        let showNcls = generalFilter[.NCL]?.0 ?? false

        let favoriteStations = allStations.filter({ showFavs && $0.isFavorite })
        let myStations = allStations.filter({ ($0.numberVisited > 0) && (!$0.isFavorite || !showFavs) })
        let restStations = allStations.filter({ showNcls && ($0.numberVisited == 0) && (!$0.isFavorite || !showFavs) })

        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], alignment: .leading, spacing: 11) {
            TilesList(title: "Ulubione", stationsToShow: favoriteStations)
            
            ForEach(Region.allCases, id: \.rawValue) { region in
                let regionStations = myStations.filter({ $0.region == region })
                TilesList(title: region.rawValue, stationsToShow: regionStations)
            }
            
            TilesList(title: "Nieodwiedzone stacje", stationsToShow: restStations)
        }
        
        if favoriteStations.isEmpty && myStations.isEmpty && restStations.isEmpty {
            ContentUnavailableView("Brak stacji", systemImage: "rectangle.on.rectangle.slash", description: Text("Odwiedź jakieś stacje lub zmień kryteria wyświetlania"))
        }
    }
}
