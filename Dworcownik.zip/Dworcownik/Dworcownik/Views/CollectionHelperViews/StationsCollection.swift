//
//  StationsCollection.swift
//  Dworcownik
//
//  Created by Krzysztof Żałobka on 03/01/2026.
//

import SwiftUI

struct StationsCollection: View {
    var allStations: [Station]
    
    var regionsFilter: [Region:(Bool,Bool)]
    var generalFilter: [Filters:(Bool,Bool)]

    var body: some View {
        let showFavs = generalFilter[.FAV]?.0 ?? true
        let showNcls = generalFilter[.NCL]?.0 ?? false

        let favoriteStations = try! allStations.filter(
            #Predicate<Station> { station in
                station.isFavorite
            }
        )
        let myStations = try! allStations.filter(
            #Predicate<Station> { station in
                (station.numberVisited > 0) && (!station.isFavorite || !showFavs)
            }
        )
        let restStations = try! allStations.filter(
            #Predicate<Station> { station in
                showNcls && (station.numberVisited == 0) && (!station.isFavorite || !showFavs)
            }
        )

        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())]) {
            if (!favoriteStations.isEmpty) && (generalFilter[.FAV]?.0 ?? true) {
                Section(
                    header:
                        Text("Ulubione")
                        .sectionHeading
                        .leftAlign
                ) {
                    ForEach(favoriteStations) { station in
                        NavigationLink(destination: StationInfoView(stationToShow: station)) {
                            CollectionTile(toShow: SLEUnion.station(station))
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            
            ForEach(Region.allCases, id: \.rawValue) { region in
                if regionsFilter[region]?.0 ?? true {
                    let regionStations = try! myStations.filter(#Predicate<Station> { station in
                        station.region == region
                    })
                    if !regionStations.isEmpty {
                        Section(
                            header:
                                Text("\(region.rawValue)")
                                .sectionHeading
                                .leftAlign
                        ) {
                            ForEach(regionStations) { station in
                                NavigationLink(destination: StationInfoView(stationToShow: station)) {
                                    CollectionTile(toShow: SLEUnion.station(station))
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                }
            }
            
            if !restStations.isEmpty {
                Section(
                    header:
                        Text("Nieodwiedzone stacje")
                        .sectionHeading
                        .leftAlign
                ) {
                    ForEach(restStations) { station in
                        NavigationLink(destination: StationInfoView(stationToShow: station)) {
                            CollectionTile(toShow: SLEUnion.station(station))
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
    
    }
}
