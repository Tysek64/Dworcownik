//
//  CollectionFilter.swift
//  Dworcownik
//
//  Created by Krzysztof Żałobka on 03/01/2026.
//

import SwiftUI

enum Filters: String, Codable, CaseIterable {
    case FAV = "Pokaż ulubione"
    case EVT = "Pokaż wydarzenia"
    case NCL = "Pokaż nieodwiedzone stacje i linie"
}

struct CollectionFilter: View {
    @Binding var regionsFilter: [Region:(Bool,Bool)]
    @Binding var operatorsFilter: [LineOperator:(Bool,Bool)]
    @Binding var generalFilter: [Filters:(Bool,Bool)]

    var body: some View {
        List {
            Section(
                header:
                    Text("Ogólne")
                    .sectionHeading
                    .leftAlign
            ) {
                ForEach(Array(generalFilter.keys.sorted(by: {$0.rawValue < $1.rawValue})), id: \.rawValue) { filter in
                    TagButton(selected: $generalFilter[filter], name: filter.rawValue, toggleState: generalFilter[filter]!.0)
                }
            }
            Section(
                header:
                    Text("Przewoźnicy")
                    .sectionHeading
                    .leftAlign
            ) {
                ForEach(Array(operatorsFilter.keys.sorted(by: {$0.name < $1.name})), id: \.name) { lineOperator in
                    TagButton(selected: $operatorsFilter[lineOperator], name: lineOperator.name, toggleState: operatorsFilter[lineOperator]!.0)
                }
            }
            Section(
                header:
                    Text("Regiony")
                    .sectionHeading
                    .leftAlign
            ) {
                ForEach(Region.allCases, id: \.rawValue) { region in
                    TagButton(selected: $regionsFilter[region], name: region.rawValue, toggleState: regionsFilter[region]!.0)
                }
            }
        }
        .navigationTitle("Filtruj kolekcję")
        .toolbarTitleDisplayMode(.inline)
    }
}

struct TagButton: View {
    @Binding var selected: (Bool,Bool)?
    let name: String
    @State var toggleState: Bool
    
    var body: some View {
        Button() {
        }
        label: {
            Toggle(name, isOn: $toggleState)
                .onChange(of: toggleState) { _, newValue in
                    if selected!.0 != toggleState {
                        selected!.0.toggle()
                    }
                }
        }
        .buttonStyle(.plain)
        .onChange(of: selected!.0) { _, newValue in
            toggleState = newValue
        }
    }
}
