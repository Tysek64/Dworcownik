//
//  LinesCollection.swift
//  Dworcownik
//
//  Created by Krzysztof Żałobka on 03/01/2026.
//

import SwiftUI

struct LinesCollection: View {
    var allLines: [Line]
    var allOperators: [LineOperator]
    var allEvents: [Event]
    
    var operatorsFilter: [LineOperator:(Bool,Bool)]
    var generalFilter: [Filters:(Bool,Bool)]
    
    var body: some View {
        let showFavs = generalFilter[.FAV]?.0 ?? true
        let showEvts = generalFilter[.EVT]?.0 ?? true
        let showNcls = generalFilter[.NCL]?.0 ?? false

        let favoriteEvents = try! allEvents.filter(
            #Predicate<Event> { event in
                event.isFavorite && showEvts
            }
        )
        let myEvents = try! allEvents.filter(
            #Predicate<Event> { event in
                (event.numberVisited > 0) && (!event.isFavorite || !showFavs) && showEvts
            }
        )
        
        let favoriteLines = try! allLines.filter(
            #Predicate<Line> { line in
                line.isFavorite
            }
        )
        let myLines = try! allLines.filter(
            #Predicate<Line> { line in
                (line.numberVisited > 0) && (!line.isFavorite || !showFavs)
            }
        )
        let restLines = try! allLines.filter(
            #Predicate<Line> { line in
                showNcls && (line.numberVisited == 0) && (!line.isFavorite || !showFavs)
            }
        )
        
        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())]) {
            if (!favoriteLines.isEmpty || !favoriteEvents.isEmpty) && generalFilter[.FAV]?.0 ?? true {
                Section(
                    header:
                        Text("Ulubione")
                        .sectionHeading
                        .leftAlign
                ) {
                    ForEach(favoriteEvents) { event in
                        NavigationLink(destination: EventInfoView(eventToShow: event)) {
                            CollectionTile(toShow: SLEUnion.event(event))
                        }
                        .buttonStyle(.plain)
                    }
                    ForEach(favoriteLines) { line in
                        NavigationLink(destination: LineInfoView(lineToShow: line)) {
                            CollectionTile(toShow: SLEUnion.line(line))
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            if (!myEvents.isEmpty) && generalFilter[.EVT]?.0 ?? true {
                Section(
                    header:
                        Text("Moje wydarzenia")
                        .sectionHeading
                        .leftAlign
                ) {
                    ForEach(myEvents) { event in
                        NavigationLink(destination: EventInfoView(eventToShow: event)) {
                            CollectionTile(toShow: SLEUnion.event(event))
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            ForEach(allOperators) { lineOperator in
                if operatorsFilter[lineOperator]?.0 ?? true {
                    let operatorName = lineOperator.name
                    let operatorLines = try! myLines.filter(#Predicate<Line> { line in
                        (line.lineOperator != nil) && (line.lineOperator!.name == operatorName)
                    })
                    if !operatorLines.isEmpty {
                        Section(
                            header:
                                Text("\(lineOperator.name)")
                                .sectionHeading
                                .leftAlign
                        ) {
                            ForEach(operatorLines) { line in
                                NavigationLink(destination: LineInfoView(lineToShow: line)) {
                                    CollectionTile(toShow: SLEUnion.line(line))
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                }
            }
            if !restLines.isEmpty {
                Section(
                    header:
                        Text("Nieodwiedzone linie")
                        .sectionHeading
                        .leftAlign
                ) {
                    ForEach(restLines) { line in
                        NavigationLink(destination: LineInfoView(lineToShow: line)) {
                            CollectionTile(toShow: SLEUnion.line(line))
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
    
    }
}
