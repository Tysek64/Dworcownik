//
//  LinesCollection.swift
//  Dworcownik
//
//  Created by Krzysztof Żałobka on 03/01/2026.
//

import SwiftUI

struct LinesCollection: View {
    var allLines: [Line]
    var allOperators: [LineOperator]
    var allEvents: [Event]
    
    var generalFilter: [Filters:(Bool,Bool)]
    
    var body: some View {
        let showFavs = generalFilter[.FAV]?.0 ?? true
        let showEvts = generalFilter[.EVT]?.0 ?? true
        let showNcls = generalFilter[.NCL]?.0 ?? false

        let favoriteEvents = allEvents.filter({ showFavs && $0.isFavorite && showEvts })
        let myEvents = allEvents.filter({ ($0.numberVisited > 0) && (!$0.isFavorite || !showFavs) && showEvts })
        
        let favoriteLines = allLines.filter({ showFavs && $0.isFavorite })
        let myLines = allLines.filter({ ($0.numberVisited > 0) && (!$0.isFavorite || !showFavs) })
        let restLines = allLines.filter({ showNcls && ($0.numberVisited == 0) && (!$0.isFavorite || !showFavs) })
        
        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], alignment: .leading, spacing: 11) {
            TilesList(title: "Ulubione", linesToShow: favoriteLines, eventsToShow: favoriteEvents)
            TilesList(title: "Moje wydarzenia", eventsToShow: myEvents)
            
            ForEach(allOperators) { lineOperator in
                let operatorLines = myLines.filter({ ($0.lineOperator != nil) && ($0.lineOperator!.name == lineOperator.name) })
                TilesList(title: lineOperator.name, linesToShow: operatorLines)
            }
            
            TilesList(title: "Nieodwiedzone linie", linesToShow: restLines)
        }
        
        if favoriteEvents.isEmpty && myEvents.isEmpty && favoriteLines.isEmpty && myLines.isEmpty && restLines.isEmpty {
            ContentUnavailableView("Brak linii", systemImage: "rectangle.on.rectangle.slash", description: Text("Odwiedź jakieś stacje lub zmień kryteria wyświetlania"))
        }
    
    }
}
