//
//  StampsCollection.swift
//  Dworcownik
//
//  Created by Krzysztof Żałobka on 03/01/2026.
//

import SwiftUI

struct StampsCollection: View {
    var allStations: [Station]
    
    var regionsFilter: [Region:(Bool,Bool)]
    var generalFilter: [Filters:(Bool,Bool)]

    var body: some View {
        let myStations = try! allStations.filter(
            #Predicate<Station> { station in
                ((station.numberVisited > 0) || (station.isFavorite))
            }
        )/*.filter(
            #Predicate<Station> { station in
                ((station.region == nil) || (regionsFilter[station.region!]?.0 ?? true))
            }
        )*/

        let myStamps: [Stamp] = myStations.map({ station in station.stamps ?? [] }).reduce([], +)
        let allStamps = try! myStamps.filter(#Predicate<Stamp> { stamp in stamp.collected }).sorted(by: {(a: Stamp, b: Stamp) -> Bool in return (a.collectedTime ?? Date.distantPast) > (b.collectedTime ?? Date.distantPast) })
        
        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())]) {
            ForEach(allStamps) { stamp in
                StampTile(stampToShow: stamp)
            }
        }
    }
}
