//
//  StampsCollection.swift
//  Dworcownik
//
//  Created by Krzysztof Żałobka on 03/01/2026.
//

import SwiftUI

struct StampsCollection: View {
    var allStations: [Station]
    
    var criteria: String
    var generalFilter: [Filters:(Bool,Bool)]

    var body: some View {
        let myStamps: [Stamp] = allStations.map({ $0.stamps ?? [] }).reduce([], +)
        let allStamps = myStamps.filter({ $0.collected && $0.passesCriteria(searchText: criteria) }).sorted(by: { ($0.collectedTime ?? Date.distantPast) > ($1.collectedTime ?? Date.distantPast) })
        
        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())], alignment: .leading) {
            ForEach(allStamps) { stamp in
                StampTile(stampToShow: stamp)
            }
        }
        
        if allStamps.isEmpty {
            ContentUnavailableView("Brak pieczątek", systemImage: "rectangle.on.rectangle.slash", description: Text("Odwiedź jakieś stacje lub zmień kryteria wyświetlania"))
        }
    }
}
