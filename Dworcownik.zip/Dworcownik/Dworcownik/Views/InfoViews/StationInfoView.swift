//
//  StationInfoView.swift
//  Dworcownik
//
//  Created by Krzysztof Żałobka on 26/12/2025.
//

import SwiftUI

struct StationInfoView: View {
    var stationToShow: Station
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 11) {
                ZStack(alignment: .topTrailing) {
                    Rectangle()
                        .fill(Color.accentColor)
                        .overlay {
                            stationToShow.imageAsset
                                .clipAndFill
                                .clipShape(.rect)
                                .blur(radius: stationToShow.isLocked ? 7 : 0, opaque: true)
                                .overlay {
                                    if stationToShow.isLocked {
                                        Image(systemName: "lock")
                                            .resizable()
                                            .scaledToFit()
                                            .padding()
                                    }
                                }
                        }
                    VStack(alignment: .trailing, spacing: 11) {
                        Grid(alignment: .leading) {
                            GridRow {
                                Image(systemName: "mappin.circle");
                                Text("\(stationToShow.numberVisited)")
                            }
                            .foregroundColor(
                                stationToShow.numberScanned > 0 ? .accentColor : .primary
                            )
                        }
                        .padding()
                        .frame(minWidth: 0, maxWidth: .infinity, alignment: .leading)
                        .glassEffect(in: .rect(cornerRadius: 34));
                        Grid(alignment: .leading) {
                            GridRow {
                                Image(systemName: "building.2");
                                Text(String(format: "%i", stationToShow.builtYear))
                            };
                            GridRow {
                                Image(systemName: "road.lanes");
                                Text("\(stationToShow.numberOfPlatforms)")
                            }
                        }
                        .padding()
                        .frame(minWidth: 0, maxWidth: .infinity, alignment: .leading)
                        .glassEffect(in: .rect(cornerRadius: 34));
                    }
                    .fixedSize(horizontal: true, vertical: false)
                    .padding(11)
                }
                .containerRelativeFrame(.vertical, count: 2, spacing: 0)
                Text("Liczba odwiedzin: ")
                    .sectionHeading
                    .padding(.horizontal)
                HStack {
                    Image(systemName: "train.side.front.car")
                        .imageScale(.large)
                    Text("\(stationToShow.numberPassed)")
                        .fontWeight(.heavy)
                    Spacer()
                    Image(systemName: "figure.walk")
                        .imageScale(.large)
                    Text("\(stationToShow.numberStopped)")
                        .fontWeight(.heavy)
                    Spacer()
                    Image(systemName: "qrcode")
                        .imageScale(.large)
                    Text("\(stationToShow.numberScanned)")
                        .fontWeight(.heavy)
                }
                .padding(.horizontal, 40)
                Text("Opis stacji: ")
                    .sectionHeading
                    .padding(.horizontal)
                Text("\(stationToShow.info)")
                    .padding(.horizontal)
                if !stationToShow.collectedStamps.isEmpty {
                    Text("Pieczątki zdobyte na stacji: ")
                        .sectionHeading
                        .padding(.horizontal)
                    ScrollView {
                        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())]) {
                            ForEach(stationToShow.collectedStamps) { stamp in
                                StampTile(stampToShow: stamp)
                            }
                        }
                        .padding()
                    }
                }
            }
        }
        .navigationTitle("\(stationToShow.name)")
        .navigationSubtitle("\(stationToShow.region?.rawValue ?? "")")
        .toolbar {
            Button () {
                stationToShow.isFavorite.toggle()
            }
            label: {
                Image(systemName: stationToShow.isFavorite ? "heart.fill" : "heart")
            }
            ShareLink(
                item: stationToShow.imageAsset,
                subject: Text("Bywam na stacji \(stationToShow.name)"),
                message: Text("Mogę się pochwalić odwiedzeniem jej już \(stationToShow.numberVisited) razy, z czego z \(stationToShow.numberStopped + stationToShow.numberScanned) razy nie tylko przejazdem!"),
                preview: SharePreview(stationToShow.name, image: stationToShow.imageAsset)
            )
        }
    }
}

#Preview {
    StationInfoView(stationToShow: Station(name: "test", info: "Opis wydarzenia opis wydarzenia opis wydarzenia opis wydarzenia opis wydarzenia opis wydarzenia opis wydarzenia", builtYear: 2000, imagePath: "os"))
}
