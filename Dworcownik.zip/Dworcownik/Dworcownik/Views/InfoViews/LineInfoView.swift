//
//  LineInfoView.swift
//  Dworcownik
//
//  Created by Krzysztof Żałobka on 29/12/2025.
//

import SwiftUI

struct LineInfoView: View {
    var lineToShow: Line
    var body: some View {
        let visitedStations: [Station] = try! lineToShow.stations?.filter(#Predicate<Station> { station in station.numberVisited > 0}) ?? []
        let notVisitedStations: [Station] = try! lineToShow.stations?.filter(#Predicate<Station> { station in station.numberVisited == 0}) ?? []
        ScrollView {
            VStack(alignment: .leading, spacing: 11) {
                ZStack(alignment: .topTrailing) {
                    Rectangle()
                        .fill(Color.accentColor)
                        .overlay {
                            lineToShow.imageAsset
                                .clipAndFill
                                .clipShape(.rect)
                        }
                    VStack(alignment: .trailing, spacing: 11) {
                        Grid(alignment: .leading) {
                            GridRow {
                                Image(systemName: "checkmark.circle");
                                Text("\(lineToShow.numberVisited) / \(lineToShow.numberTotal)")
                            }
                            .foregroundColor(
                                lineToShow.numberVisited == lineToShow.numberTotal ? .accentColor : .primary
                            )
                        }
                        .padding()
                        .frame(minWidth: 0, maxWidth: .infinity, alignment: .leading)
                        .glassEffect(in: .rect(cornerRadius: 34));
                        Grid(alignment: .leading) {
                            GridRow {
                                Image(systemName: "calendar");
                                Text(String(format: "%i", lineToShow.builtYear))
                            };
                            GridRow {
                                Image(systemName: "point.bottomleft.forward.to.point.topright.filled.scurvepath");
                                Text("\(lineToShow.length) km")
                            };
                            GridRow {
                                Image(systemName: "tram.circle");
                                Text("\(lineToShow.numberStations)")
                            };
                            GridRow {
                                Image(systemName: "tachometer");
                                Text("\(lineToShow.maxSpeed) km/h")
                            }
                        }
                        .padding()
                        .frame(minWidth: 0, maxWidth: .infinity, alignment: .leading)
                        .glassEffect(in: .rect(cornerRadius: 34));
                    }
                    .padding(11)
                    .fixedSize(horizontal: true, vertical: false)
                }
                .containerRelativeFrame(.vertical, count: 2, spacing: 0)
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], alignment: .leading, spacing: 11) {
                    TilesList(title: "Nieodwiedzone stacje: ", stationsToShow: notVisitedStations)
                    TilesList(title: "Odwiedzone stacje: ", stationsToShow: visitedStations)
                }
                .padding(.horizontal)
            }
        }
        .navigationTitle("\(lineToShow.name)")
        .navigationSubtitle("\(lineToShow.lineOperator?.name ?? "")")
        .toolbar {
            Button () {
                lineToShow.isFavorite.toggle()
            }
            label: {
                Image(systemName: lineToShow.isFavorite ? "heart.fill" : "heart")
            }
            ShareLink(
                item: lineToShow.imageAsset,
                subject: Text("Odwiedzam stacje na linii '\(lineToShow.name)'"),
                message: Text("Mogę się pochwalić odwiedzeniem już \(lineToShow.numberVisited) z \(lineToShow.numberTotal) stacji!"),
                preview: SharePreview(lineToShow.name, image: lineToShow.imageAsset)
            )
        }
    }
}

#Preview {
    LineInfoView(lineToShow: Line(name: "test", builtYear: 2000))
}
