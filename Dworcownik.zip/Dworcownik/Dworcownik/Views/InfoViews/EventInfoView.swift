//
//  EventInfoView.swift
//  Dworcownik
//
//  Created by Krzysztof Żałobka on 29/12/2025.
//

import SwiftUI

struct EventInfoView: View {
    var eventToShow: Event
    var body: some View {
        let visitedStations: [Station] = try! eventToShow.stations?.filter(#Predicate<Station> { station in station.numberVisited > 0}) ?? []
        let notVisitedStations: [Station] = try! eventToShow.stations?.filter(#Predicate<Station> { station in station.numberVisited == 0}) ?? []
        ScrollView {
            VStack(alignment: .leading, spacing: 10) {
                ZStack(alignment: .topTrailing) {
                    Rectangle()
                        .fill(Color.accentColor)
                        .overlay {
                            eventToShow.imageAsset
                                .clipAndFill
                        }
                    VStack(alignment: .trailing, spacing: 11) {
                        Grid(alignment: .leading) {
                            GridRow {
                                Image(systemName: "checkmark.circle");
                                Text("\(eventToShow.numberVisited)/\(eventToShow.numberTotal)")
                            }
                            .foregroundColor(
                                eventToShow.numberVisited == eventToShow.numberTotal ? .accentColor : .primary
                            )
                        }
                        .padding(11)
                        .frame(minWidth: 0, maxWidth: .infinity, alignment: .leading)
                        .glassEffect(in: .rect(cornerRadius: 34));
                    }
                    .padding()
                    .fixedSize(horizontal: true, vertical: false)
                }
                .containerRelativeFrame(.vertical, count: 2, spacing: 0)
                
                
                Text("Opis wydarzenia: ")
                    .sectionHeading
                    .padding(.horizontal)
                Text("\(eventToShow.info)")
                    .padding(.horizontal)
                
                
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], alignment: .leading) {
                    if !notVisitedStations.isEmpty {
                        Section(
                            header:
                                Text("Nieodwiedzone stacje: ")
                                .sectionHeading
                        ) {
                            ForEach(notVisitedStations) { station in
                                NavigationLink(destination: StationInfoView(stationToShow: station)) {
                                    CollectionTile(toShow: SLEUnion.station(station))
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                    if !visitedStations.isEmpty {
                        Section(
                            header:
                                Text("Odwiedzone stacje: ")
                                .sectionHeading
                        ) {
                            ForEach(visitedStations) { station in
                                NavigationLink(destination: StationInfoView(stationToShow: station)) {
                                    CollectionTile(toShow: SLEUnion.station(station))
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                }
                .padding(.horizontal)
            }
        }
        .navigationTitle("\(eventToShow.name)")
        .navigationSubtitle("\(eventToShow.startDate.dateOnly) ~ \(eventToShow.endDate.dateOnly)")
        .toolbar {
            Button () {
                eventToShow.isFavorite.toggle()
            }
            label: {
                Image(systemName: eventToShow.isFavorite ? "heart.fill" : "heart")
            }
            ShareLink(
                item: eventToShow.imageAsset,
                subject: Text("Biorę udział w '\(eventToShow.name)'"),
                message: Text("Mogę się pochwalić odwiedzeniem już \(eventToShow.numberVisited) z \(eventToShow.numberTotal) stacji!"),
                preview: SharePreview(eventToShow.name, image: eventToShow.imageAsset)
            )
        }
    }
}

#Preview {
    EventInfoView(eventToShow: Event(name: "test", info: "Opis wydarzenia opis wydarzenia opis wydarzenia opis wydarzenia opis wydarzenia opis wydarzenia opis wydarzenia"))
}
