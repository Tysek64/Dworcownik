//
//  ContentView.swift
//  Dworcownik
//
//  Created by stud on 13/11/2025.
//

import SwiftUI
import SwiftData
import MapKit

struct MainView: View {
    @EnvironmentObject private var locationManager: LocationManager
    @Environment(\.modelContext) var modelContext: ModelContext
    
    @Query private var allStations: [Station]
    
    var body: some View {
        let sortedStations = allStations.sorted(by: {(a: Station, b: Station) -> Bool in
            a.calculateDistance(userLocation: locationManager.currentLocation) < b.calculateDistance(userLocation: locationManager.currentLocation)
        })
        VStack {
            TabView {
                Tab("Dom", systemImage: "house.fill") {
                    HomeView()
                }
                Tab("Mapa", systemImage: "map.fill") {
                    MapView()
                }
                Tab("W podróży", systemImage: "tachometer") {
                    SpeedView()
                }
                Tab("Kolekcja", systemImage: "book.pages.fill") {
                    CollectionView()
                }
                /*
                Tab("Skanuj kod", systemImage: "qrcode", role: .search) {
                    ScannerView()
                }
                */
                Tab("Test", systemImage: "flask.fill", role: .search) {
                    TestView()
                }
            }
        }
        updateStation(closestStation: sortedStations[0], currentLocation: locationManager.currentLocation, currentSpeed: locationManager.currentSpeed)
    }
    
    // to nie powinno tu być
    func updateStation(closestStation: Station, currentLocation: CLLocation, currentSpeed: Double) -> EmptyView {
        if closestStation.calculateDistance(userLocation: currentLocation) < 0.3 {
            if currentStation != closestStation {
                currentStatus = 0
            }
            currentStation = closestStation
            if (currentSpeed < 1) && (currentStatus < 2) {
                currentStation?.addStop(resetPasses: currentStatus > 0)
                try? modelContext.save()
                currentStatus = 2
            } else if currentStatus < 1 {
                currentStatus = 1
                currentStation?.addPass()
                try? modelContext.save()
            }
        } else if closestStation.calculateDistance(userLocation: currentLocation) > 1 {
            currentStation = nil
            currentStatus = 0
        }
        return EmptyView()
    }
}

#Preview {
    MainView().modelContainer(Station.preview).environmentObject(LocationManager())
}
