//
//  TilesList.swift
//  Dworcownik
//
//  Created by Krzysztof Żałobka on 05/01/2026.
//

import SwiftUI

struct TilesList: View {
    var title: String
    var stationsToShow: [Station] = []
    var linesToShow: [Line] = []
    var eventsToShow: [Event] = []

    @State private var shown: Bool = true
    
    var body: some View {
        if !stationsToShow.isEmpty || !linesToShow.isEmpty || !eventsToShow.isEmpty {
            Section(
                isExpanded: $shown,
                content: {
                    ForEach(stationsToShow) { station in
                        CollectionTile(toShow: SLEUnion.station(station))
                    }
                    ForEach(eventsToShow) { event in
                        CollectionTile(toShow: SLEUnion.event(event))
                    }
                    ForEach(linesToShow) { line in
                        CollectionTile(toShow: SLEUnion.line(line))
                    }
                },
                header: {
                    Button () {
                        shown.toggle()
                    }
                    label: {
                        HStack {
                            Text(title)
                                .sectionHeading
                            Spacer()
                            Image(systemName: shown ? "chevron.up" : "chevron.down")
                                .imageScale(.small)
                                .foregroundStyle(.primary)
                        }
                    }
                    .buttonStyle(.plain)
                }
            )
        } else {
            EmptyView()
        }
    }
}
