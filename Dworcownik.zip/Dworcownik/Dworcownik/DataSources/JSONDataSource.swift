//
//  JSONDataSource.swift
//  Dworcownik
//
//  Created by Krzysztof Żałobka on 05/01/2026.
//

import Foundation

class JSONDataSource: DataSource {
    func retrieveData() -> ([Station], [(Line, (String, [Station]))], [(Event, [Station])]) {
        var regions: [String:Region?] = [:]
        var operators: [String:String] = [:]
        
        var stations: [String:Station] = [:]
        var lines: [(Line,(String, [Station]))] = []
        var events: [(Event,[Station])] = []
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy"
        dateFormatter.timeZone = .gmt
        
        print("Initiating data read...")
        
        if let url = Bundle.main.url(forResource: "data", withExtension: "json"),
           let data = try? Data(contentsOf: url),
           let json = try? JSONSerialization.jsonObject(with: data, options: .fragmentsAllowed) as? [String:Any] {
            for region in (json["regions"] as! [String:String]).keys {
                regions[region] = Region(rawValue: (json["regions"] as! [String:String])[region]!)
            }
            operators = json["operators"] as! [String:String]

            for station in json["stations"] as! [[String:Any]] {
                print("Inserting \(station["name"] as! String)...")
                stations[station["imagePath"] as! String] =
                Station(
                    name: station["name"] as! String,
                    info: station["info"] as! String,
                    builtYear: station["builtYear"] as! Int,
                    numberOfPlatforms: station["numberOfPlatforms"] as! Int,
                    region: regions[station["region"] as! String] ?? nil,
                    latitude: station["latitude"] as! Double,
                    longitude: station["longitude"] as! Double,
                    imagePath: station["imagePath"] as? String
                )
            }
            
            for line in json["lines"] as! [[String:Any]] {
                lines.append((
                    Line(
                        name: line["name"] as! String,
                        builtYear: line["builtYear"] as! Int,
                        length: line["length"] as! Int,
                        maxSpeed: line["maxSpeed"] as! Int,
                        numberStations: line["numberStations"] as! Int,
                        imagePath: line["imagePath"] as? String
                    ),
                    (operators[line["lineOperator"] as! String] ?? "", (line["stations"] as! [String]).map({ stations[$0] ?? Station(name: "test") }))
                ))
            }
            
            for event in json["events"] as! [[String:Any]] {
                events.append((
                    Event(
                        name: event["name"] as! String,
                        info: event["info"] as! String,
                        startDate: dateFormatter.date(from: event["startDate"] as! String) ?? Date.distantPast,
                        endDate: dateFormatter.date(from: event["endDate"] as! String) ?? Date.distantFuture,
                        imagePath: event["imagePath"] as? String
                    ),
                    (event["stations"] as! [String]).map({ stations[$0] ?? Station(name: "test") })
                ))
            }
        }
        
        return (Array(stations.values), lines, events)
    }
}
