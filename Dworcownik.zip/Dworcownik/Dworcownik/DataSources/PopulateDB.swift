//
//  PopulateDB.swift
//  Dworcownik
//
//  Created by Krzysztof Żałobka on 26/12/2025.
//

import Foundation
import SwiftData

protocol DataSource {
    func retrieveData() -> ([Station], [(Line, (String, [Station]))], [(Event, [Station])])
}

class DBSeeder {
    var context: ModelContext
    var source: DataSource
    
    init(context: ModelContext, source: DataSource) {
        self.context = context
        self.source = source
    }
    
    func nukeAndPopulate () {
        nukeDB()
        populateDB()
    }
    
    func nukeDB () {
        try! context.delete(model: Stamp.self)
        try! context.delete(model: Station.self)
        try! context.delete(model: LineOperator.self)
        try! context.delete(model: Line.self)
        try! context.delete(model: Event.self)
    }
    
    func populateDB () {
        nukeDB()
        
        defer {
            try? context.save()
        }
        
        let (stations, lines, events) = source.retrieveData()
        let DBOperators = try! context.fetch(FetchDescriptor<LineOperator>())
        var operators = Dictionary(
            uniqueKeysWithValues: zip(
                DBOperators.map({$0.name}),
                DBOperators
            )
        )
        
        for station in stations {
            if findStation(station: station.name) == nil {
                context.insert(station)
                
                for i in 1...3 {
                    station.addStamp(stamp: Stamp(station: station, difficulty: i, imagePath: "\(station.imagePath ?? "")_s\(i)"))
                }
            }
        }
        
        for (DBLine, (lineOperator, lineStations)) in lines {
            if !operators.keys.contains(lineOperator) {
                operators[lineOperator] = LineOperator(name: lineOperator)
            }
            let line = findLine(line: DBLine.name) ?? DBLine
            line.lineOperator = operators[lineOperator]
            for station in lineStations {
                let DBStation = findStation(station: station.name)
                line.stations?.append(DBStation ?? station)
            }
        }
        
        for (DBEvent, eventStations) in events {
            let event = findEvent(event: DBEvent.name) ?? DBEvent
            for station in eventStations {
                let DBStation = findStation(station: station.name)
                event.stations?.append(DBStation ?? station)
                findStation(station: station.name)?.addStamp(stamp: Stamp(station: station, event: event, difficulty: 2, imagePath: "\(station.imagePath ?? "")_\(event.imagePath ?? "")_se"))
            }
        }
    }
    
    func findStation (station: String) -> Station? {
        let existCheck = try! context.fetch(FetchDescriptor<Station>(predicate: #Predicate<Station>{DBStation in DBStation.name == station}))
        
        return existCheck.first
    }
    
    func findLine (line: String) -> Line? {
        let existCheck = try! context.fetch(FetchDescriptor<Line>(predicate: #Predicate<Line>{DBLine in DBLine.name == line}))
        
        return existCheck.first
    }
    
    func findEvent (event: String) -> Event? {
        let existCheck = try! context.fetch(FetchDescriptor<Event>(predicate: #Predicate<Event>{DBEvent in DBEvent.name == event}))
        
        return existCheck.first
    }
}
