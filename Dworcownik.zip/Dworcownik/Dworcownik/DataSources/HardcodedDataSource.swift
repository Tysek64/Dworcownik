//
//  HardcodedDataSource.swift
//  Dworcownik
//
//  Created by Krzysztof Żałobka on 05/01/2026.
//

import Foundation

class HardcodedDataSource: DataSource {
    func retrieveData() -> ([Station], [(Line, (String, [Station]))], [(Event, [Station])]) {
        let wm = Station(name: "Wałbrzych Miasto",      builtYear: 1853, region: .DS, latitude: 50.786, longitude: 16.283, imagePath: "wm")
        let ws = Station(name: "Wałbrzych Szczawienko", builtYear: 1853, region: .DS, latitude: 50.816, longitude: 16.303, imagePath: "ws")
        let wg = Station(name: "Wrocław Główny",        builtYear: 1857, region: .DS, latitude: 51.098, longitude: 17.037, imagePath: "wg")
        let pg = Station(name: "Poznań Główny",         builtYear: 1879, region: .WP, latitude: 52.402, longitude: 16.912, imagePath: "pg")
        let gg = Station(name: "Gdynia Główna",         builtYear: 1894, region: .PM, latitude: 54.521, longitude: 18.529, imagePath: "gg")
        let gs = Station(name: "Gdańsk Stocznia",       builtYear: 1952, region: .PM, latitude: 54.364, longitude: 18.641, imagePath: "gs")
        let ww = Station(name: "Warszawa Wschodnia",    builtYear: 1866, region: .MZ, latitude: 52.252, longitude: 21.051, imagePath: "ww")
        let kt = Station(name: "Katowice",              builtYear: 1846, region: .SL, latitude: 50.257, longitude: 19.017, imagePath: "kt")
        let os = Station(name: "Oświęcim",              builtYear: 1856, region: .MA, latitude: 50.042, longitude: 19.200, imagePath: "os")
        let wo = Station(name: "Warszawa Ochota",       builtYear: 1963, region: .MZ, latitude: 52.226, longitude: 20.990, imagePath: "wo")
        
        let stations = [wm, ws, wg, pg, gg, gs, ww, kt, os, wo]
        
        let l001:(Line,(String, [Station])) = (Line(name: "Linia 1", builtYear: 1848, imagePath: "l001",),
                    ("PKP Intercity", [kt, ww])
        )
        let l004:(Line,(String, [Station])) = (Line(name: "Linia 4", builtYear: 1977, imagePath: "l004",),
                    ("PKP Intercity", [])
        )
        let l009:(Line,(String, [Station])) = (Line(name: "Linia 9", builtYear: 1876, imagePath: "l009",),
                    ("PKP Intercity", [gg])
        )
        let l138:(Line,(String, [Station])) = (Line(name: "Linia 138", builtYear: 1863, imagePath: "l138",),
                    ("Koleje Śląskie", [kt, os])
        )
        let l250:(Line,(String, [Station])) = (Line(name: "Linia 250", builtYear: 1956, imagePath: "l250",),
                    ("PKP SKM Trójmiasto", [gg, gs])
        )
        let l274:(Line,(String, [Station])) = (Line(name: "Linia 274", builtYear: 1868, imagePath: "l274",),
                    ("Koleje Dolnośląskie", [wm, ws, wg])
        )
        let l448:(Line,(String, [Station])) = (Line(name: "Linia 448", builtYear: 1933, imagePath: "l448",),
                    ("Koleje Mazowieckie", [ww, wo])
        )
        let l450:(Line,(String, [Station])) = (Line(name: "Linia 450", builtYear: 1933, imagePath: "l448",),
                    ("Koleje Śląskie", [gg, kt])
        )

        let lines = [l001, l004, l009, l138, l250, l274, l448, l450]
        
        let ev1:(Event,[Station]) = (Event(
            name: "Wydarzenie 1",
            info: "Opis pierwszego wydarzenia",
            startDate: Calendar.current.date(byAdding: DateComponents(day: -1), to: Date.now)!,
            imagePath: "ev1",
        ),
                   [wm, wg, wo]
        )
        let ev2:(Event,[Station]) = (Event(
            name: "Wydarzenie 2",
            info: "Opis drugiego wydarzenia",
            startDate: Calendar.current.date(byAdding: DateComponents(day: -3), to: Date.now)!,
            imagePath: "ev2",
        ),
                   [wm, wg, pg, gg, gs, ww]
        )
        let ev3:(Event,[Station]) = (Event(
            name: "Wydarzenie 3",
            info: "Opis trzeciego wydarzenia",
            startDate: Calendar.current.date(byAdding: DateComponents(day: -7), to: Date.now)!,
            imagePath: "ev3",
        ),
                   [wm, wg, kt, os]
        )
        
        let events = [ev1, ev2, ev3]
        
        return (stations, lines, events)
    }
}
