//
//  MapView.swift
//  Dworcownik
//
//  Created by stud on 28/11/2025.
//

import SwiftUI
import MapKit

struct MapView: View {
    var body: some View {
        Map()
    }
}

#Preview {
    MapView()
}
