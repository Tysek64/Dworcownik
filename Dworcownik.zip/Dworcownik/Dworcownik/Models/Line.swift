//
//  Line.swift
//  Dworcownik
//
//  Created by Krzysztof Żałobka on 29/12/2025.
//

import Foundation
import SwiftData
import SwiftUI

@Model
class Line {
    var name: String
    var builtYear: Int
    var length: Int
    var maxSpeed: Int
    var numberStations: Int
    var imagePath: String?
    
    var imageAsset: Image {
        if imagePath != nil,
           let url = Bundle.main.url(forResource: imagePath, withExtension: "jpg", subdirectory: "Images/Lines"),
           let data = try? Data(contentsOf: url),
           let image = UIImage(data: data) {
            return Image(uiImage: image)
        } else {
            return Image(.defaultLine)
        }
    }

    var isFavorite: Bool = false
    var addedDate: Date = Date.now

    @Relationship(deleteRule: .nullify, inverse: \Station.lines)
    var stations: [Station]? = []
    
    var lineOperator: LineOperator?
    
    var numberTotal: Int {
        return stations?.count ?? 0
    }
    
    var numberVisited: Int {
        return try! stations?.filter(#Predicate<Station> { station in
            (station.numberPassed + station.numberStopped + station.numberScanned) > 0
        }).count ?? 0
    }

    init(
        name: String,
        lineOperator: LineOperator? = nil,
        builtYear: Int,
        length: Int = 0,
        maxSpeed: Int = 0,
        numberStations: Int = 0,
        imagePath: String? = nil,
        stations: [Station]? = []
    ) {
        self.name = name
        self.lineOperator = lineOperator
        self.builtYear = builtYear
        self.length = length
        self.maxSpeed = maxSpeed
        self.numberStations = numberStations
        self.imagePath = imagePath
        self.stations = stations
    }
    
    func passesCriteria (searchText: String) -> Bool {
        return (self.name.lowercased().contains(searchText.lowercased()) || self.lineOperator?.name.lowercased().contains(searchText.lowercased()) ?? false) || (searchText.isEmpty)
    }
}
