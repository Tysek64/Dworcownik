//
//  Event.swift
//  Dworcownik
//
//  Created by Krzysztof Żałobka on 24/12/2025.
//

import Foundation
import SwiftData
import SwiftUI

@Model
class Event {
    var name: String
    var info: String
    var startDate: Date
    var endDate: Date
    var imagePath: String?
    
    var imageAsset: Image {
        if imagePath != nil,
           let url = Bundle.main.url(forResource: imagePath, withExtension: "jpg", subdirectory: "Images/Events"),
           let data = try? Data(contentsOf: url),
           let image = UIImage(data: data) {
            return Image(uiImage: image)
        } else {
            return Image(.defaultEvent)
        }
    }
    
    @Relationship(deleteRule: .nullify, inverse: \Station.events)
    var stations: [Station]? = []
    
    var numberTotal: Int {
        return stations?.count ?? 0
    }
    
    var numberVisited: Int {
        return try! stations?.filter(#Predicate<Station> { station in
            (station.numberPassed + station.numberStopped + station.numberScanned) > 0
        }).count ?? 0
    }
    
    var stamps: [Stamp]? = []
    
    var isFavorite: Bool = false

    init(
        name: String,
        info: String = "",
        startDate: Date = Date.distantPast,
        endDate: Date = Date.distantFuture,
        imagePath: String? = nil,
        stations: [Station]? = []
    ) {
        self.name = name
        self.info = info
        self.startDate = startDate
        self.endDate = endDate
        self.imagePath = imagePath
        self.stations = stations
    }
    
    func passesCriteria (searchText: String) -> Bool {
        return (self.name.lowercased().contains(searchText.lowercased())) || (searchText.isEmpty)
    }
}
