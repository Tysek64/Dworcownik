//
//  Station.swift
//  Dworcownik
//
//  Created by Krzysztof Żałobka on 24/12/2025.
//

import Foundation
import SwiftData
import CoreLocation
import SwiftUI

@Model
class Station {
    var name: String
    var info: String
    var builtYear: Int
    var numberOfPlatforms: Int
    var region: Region?
    var latitude: Double
    var longitude: Double
    var imagePath: String?
    
    var imageAsset: Image {
        if imagePath != nil,
           let url = Bundle.main.url(forResource: imagePath, withExtension: "jpg", subdirectory: "Images/Stations"),
           let data = try? Data(contentsOf: url),
           let image = UIImage(data: data) {
            return Image(uiImage: image)
        } else {
            return Image(.defaultStation)
        }
    }
    
    var numberVisited: Int {
        return numberPassed + numberStopped + numberScanned
    }
    var isLocked: Bool {
        return numberVisited == 0
    }
    var isCompleted: Bool {
        return numberScanned > 0
    }
    private(set) var numberPassed: Int = 0
    private(set) var numberStopped: Int = 0
    private(set) var numberScanned: Int = 0
    
    var isFavorite: Bool = false
    
    var events: [Event]? = []
    var lines: [Line]? = []
    
    var stamps: [Stamp]? = []
    
    var collectedStamps: [Stamp] {
        return stamps != nil ? try! stamps!.filter(
            #Predicate<Stamp> { stamp in
                stamp.collected
            }
        ) : []
    }

    init(
        name: String,
        info: String = "",
        builtYear: Int = 2000,
        numberOfPlatforms: Int = 0,
        region: Region? = nil,
        latitude: Double = 0,
        longitude: Double = 0,
        imagePath: String? = nil
    ) {
        self.name = name
        self.info = info
        self.builtYear = builtYear
        self.numberOfPlatforms = numberOfPlatforms
        self.region = region
        self.latitude = latitude
        self.longitude = longitude
        self.imagePath = imagePath
    }
    
    func calculateDistance (userLocation: CLLocation) -> Double {
        return userLocation.distance(
            from: CLLocation(
                latitude: CLLocationDegrees(floatLiteral: self.latitude),
                longitude: CLLocationDegrees(floatLiteral: self.longitude)
            )
        ) / 1000
    }
    
    func addPass () {
        self.numberPassed += 1
        for stamp in stamps ?? [] {
            if stamp.event == nil || (Date.now >= stamp.event!.startDate && Date.now <= stamp.event!.endDate) {
                if !stamp.collected && (stamp.difficulty <= 1) {
                    stamp.collectedTime = Date.now
                }
                stamp.collected = (stamp.difficulty <= 1) || stamp.collected
            }
        }
    }
    
    func addStop (resetPasses: Bool) {
        if resetPasses {
            self.numberPassed -= 1
        }
        self.numberStopped += 1
        for stamp in stamps ?? [] {
            if stamp.event == nil || (Date.now >= stamp.event!.startDate && Date.now <= stamp.event!.endDate) {
                if !stamp.collected && (stamp.difficulty <= 2) {
                    stamp.collectedTime = Date.now
                }
                stamp.collected = (stamp.difficulty <= 2) || stamp.collected
            }
        }
    }
    
    func addScan (resetStops: Bool = true) {
        if resetStops {
            self.numberStopped -= 1
        }
        self.numberScanned += 1
        for stamp in stamps ?? [] {
            if stamp.event == nil || (Date.now >= stamp.event!.startDate && Date.now <= stamp.event!.endDate) {
                if !stamp.collected && (stamp.difficulty <= 3) {
                    stamp.collectedTime = Date.now
                }
                stamp.collected = (stamp.difficulty <= 3) || stamp.collected
            }
        }
    }
    
    func passesCriteria (searchText: String) -> Bool {
        return (self.name.lowercased().contains(searchText.lowercased()) || self.region?.rawValue.lowercased().contains(searchText.lowercased()) ?? false) || (searchText.isEmpty)
    }
    
    func addStamp (stamp: Stamp) {
        for existingStamp in stamps ?? [] {
            if existingStamp.event == stamp.event && existingStamp.difficulty == stamp.difficulty {
                return
            }
        }
        
        stamps?.append(stamp)
    }
}

enum Region: String, Codable, CaseIterable {
    case DS = "Dolnośląskie"
    case KP = "Kujawsko-pomorskie"
    case LU = "Lubelskie"
    case LB = "Lubuskie"
    case LD = "Łódzkie"
    case MA = "Małopolskie"
    case MZ = "Mazowieckie"
    case OP = "Opolskie"
    case PK = "Podkarpackie"
    case PD = "Podlaskie"
    case PM = "Pomorskie"
    case SL = "Śląskie"
    case SK = "Świętokrzyskie"
    case WN = "Warmińsko-mazurskie"
    case WP = "Wielkopolskie"
    case ZP = "Zachodniopomorskie"
}
