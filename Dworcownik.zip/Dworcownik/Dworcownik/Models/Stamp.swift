//
//  Stamp.swift
//  Dworcownik
//
//  Created by Krzysztof Żałobka on 29/12/2025.
//

import Foundation
import SwiftData
import SwiftUI

@Model
class Stamp {
    @Relationship(deleteRule: .nullify, inverse: \Station.stamps)
    var station: Station?
    @Relationship(deleteRule: .nullify, inverse: \Event.stamps)
    var event: Event? = nil
    
    var difficulty: Int
    var collected: Bool = false
    var collectedTime: Date? = nil
    
    var imagePath: String?
    
    var imageAsset: Image {
        if imagePath != nil,
           let url = Bundle.main.url(forResource: imagePath, withExtension: "png", subdirectory: "Images/Stamps"),
           let data = try? Data(contentsOf: url),
           let image = UIImage(data: data) {
            return Image(uiImage: image)
        } else {
            return Image(.defaultStamp)
        }
    }
    
    init(
        station: Station,
        event: Event? = nil,
        difficulty: Int = 1,
        imagePath: String? = nil
    ) {
        self.station = station
        self.event = event
        self.difficulty = difficulty
        self.imagePath = imagePath
    }
    
    func passesCriteria (searchText: String) -> Bool {
        return (self.station?.passesCriteria(searchText: searchText) ?? false || self.event?.passesCriteria(searchText: searchText) ?? false) || (searchText.isEmpty)
    }
}
