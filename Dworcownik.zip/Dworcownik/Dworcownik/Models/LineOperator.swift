//
//  LineOperator.swift
//  Dworcownik
//
//  Created by Krzysztof Żałobka on 02/01/2026.
//

import Foundation
import SwiftData

@Model
class LineOperator {
    var name: String
    @Relationship(deleteRule: .cascade, inverse: \Line.lineOperator)
    var lines: [Line] = []
    
    init(
        name: String,
    ) {
        self.name = name
    }
}
