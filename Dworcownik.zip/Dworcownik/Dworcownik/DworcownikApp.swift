//
//  DworcownikApp.swift
//  Dworcownik
//
//  Created by stud on 13/11/2025.
//

import SwiftUI

@main
struct DworcownikApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
