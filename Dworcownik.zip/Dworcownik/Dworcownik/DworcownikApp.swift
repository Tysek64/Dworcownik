//
//  DworcownikApp.swift
//  Dworcownik
//
//  Created by stud on 13/11/2025.
//

import SwiftUI
import SwiftData

@main
struct DworcownikApp: App {
    @StateObject var locationManager: LocationManager
    
    let container: ModelContainer
    
    var body: some Scene {
        WindowGroup {
            MainView()
        }
        .modelContainer(container)
        .environmentObject(locationManager)
    }
    
    init () {
        _locationManager = StateObject(wrappedValue: LocationManager())
        let schema = Schema([Station.self, Event.self, Line.self, Stamp.self, LineOperator.self])
        let config = ModelConfiguration("Dworcownik", schema: schema)
        do {
            try container = ModelContainer(for: schema, configurations: config)
        } catch {
            print(error.localizedDescription)
            try! container = ModelContainer(for: schema, configurations: ModelConfiguration(isStoredInMemoryOnly: true))
        }
        print(URL.applicationSupportDirectory.path())
        DBSeeder(context: container.mainContext, source: JSONDataSource()).populateDB()
        container.mainContext.autosaveEnabled = true
    }
}
