//
//  SpeedView.swift
//  Dworcownik
//
//  Created by stud on 28/11/2025.
//

import SwiftUI

struct SpeedView: View {
    var body: some View {
        VStack {
            ThreeWayTile(first: "Prędkościomierz");
            HStack {
                ThreeWayTile(
                    first: "Obecna prędkość",
                    second: "119,9",
                    third: "km/h"
                );
                ThreeWayTile(
                    first: "Maksymalna prędkość",
                    second: "160,3",
                    third: "km/h"
                );
            }
            ThreeWayTile(first: "Najbliższe stacje");
            HStack {
                ThreeWayTile(
                    first: "Nazwa stacji 1",
                    second: "1,5",
                    third: "km"
                );
                ThreeWayTile(
                    first: "Nazwa stacji 2",
                    second: "2,0",
                    third: "km"
                );
            }
        }
        .padding()
    }
}

#Preview {
    SpeedView()
}
