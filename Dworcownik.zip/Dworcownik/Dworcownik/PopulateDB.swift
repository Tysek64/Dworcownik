//
//  PopulateDB.swift
//  Dworcownik
//
//  Created by Krzysztof Żałobka on 26/12/2025.
//

import Foundation
import SwiftData

class DBSeeder {
    var context: ModelContext
    
    init(context: ModelContext) {
        self.context = context
    }
    
    func nukeAndPopulate () {
        nukeDB()
        populateDB()
    }
    
    func nukeDB () {
        try! context.delete(model: Stamp.self)
        try! context.delete(model: Station.self)
        try! context.delete(model: LineOperator.self)
        try! context.delete(model: Line.self)
        try! context.delete(model: Event.self)
    }
    
    func populateDB () {
        defer {
            try? context.save()
        }
        
        let wm = Station(name: "Wałbrzych Miasto",      builtYear: 1853, region: .DS, latitude: 50.786, longitude: 16.283, imagePath: "wm")
        let ws = Station(name: "Wałbrzych Szczawienko", builtYear: 1853, region: .DS, latitude: 50.816, longitude: 16.303, imagePath: "ws")
        let wg = Station(name: "Wrocław Główny",        builtYear: 1857, region: .DS, latitude: 51.098, longitude: 17.037, imagePath: "wg")
        let pg = Station(name: "Poznań Główny",         builtYear: 1879, region: .WP, latitude: 52.402, longitude: 16.912, imagePath: "pg")
        let gg = Station(name: "Gdynia Główna",         builtYear: 1894, region: .PM, latitude: 54.521, longitude: 18.529, imagePath: "gg")
        let gs = Station(name: "Gdańsk Stocznia",       builtYear: 1952, region: .PM, latitude: 54.364, longitude: 18.641, imagePath: "gs")
        let ww = Station(name: "Warszawa Wschodnia",    builtYear: 1866, region: .MZ, latitude: 52.252, longitude: 21.051, imagePath: "ww")
        let kt = Station(name: "Katowice",              builtYear: 1846, region: .SL, latitude: 50.257, longitude: 19.017, imagePath: "kt")
        let os = Station(name: "Oświęcim",              builtYear: 1856, region: .MA, latitude: 50.042, longitude: 19.200, imagePath: "os")
        let wo = Station(name: "Warszawa Ochota",       builtYear: 1963, region: .MZ, latitude: 52.226, longitude: 20.990, imagePath: "wo")
        
        var stations = [wm, ws, wg, pg, gg, gs, ww, kt, os, wo]
        
        let pkpic = LineOperator(name: "PKP Intercity")
        let ks = LineOperator(name: "Koleje Śląskie")
        let skmt = LineOperator(name: "PKP SKM Trójmiasto")
        let kd = LineOperator(name: "Koleje Dolnośląskie")
        let kmkol = LineOperator(name: "Koleje Mazowieckie")
        
        let l001:(Line,[Station]) = (Line(name: "Linia 1", lineOperator: pkpic, builtYear: 1848, imagePath: "l001",),
                    [kt, ww]
        )
        let l004:(Line,[Station]) = (Line(name: "Linia 4", lineOperator: pkpic, builtYear: 1977, imagePath: "l004",),
                    []
        )
        let l009:(Line,[Station]) = (Line(name: "Linia 9", lineOperator: pkpic, builtYear: 1876, imagePath: "l009",),
                    [gg]
        )
        let l138:(Line,[Station]) = (Line(name: "Linia 138", lineOperator: ks, builtYear: 1863, imagePath: "l138",),
                    [kt, os]
        )
        let l250:(Line,[Station]) = (Line(name: "Linia 250", lineOperator: skmt, builtYear: 1956, imagePath: "l250",),
                    [gg, gs]
        )
        let l274:(Line,[Station]) = (Line(name: "Linia 274", lineOperator: kd, builtYear: 1868, imagePath: "l274",),
                    [wm, ws, wg]
        )
        let l448:(Line,[Station]) = (Line(name: "Linia 448", lineOperator: kmkol, builtYear: 1933, imagePath: "l448",),
                    [ww, wo]
        )
        
        let lines = [l001, l004, l009, l138, l250, l274, l448]
        
        let ev1:(Event,[Station]) = (Event(
            name: "Wydarzenie 1",
            info: "Opis pierwszego wydarzenia",
            startDate: Calendar.current.date(byAdding: DateComponents(day: -1), to: Date.now)!,
            imagePath: "ev1",
        ),
                   [wm, wg, wo]
        )
        let ev2:(Event,[Station]) = (Event(
            name: "Wydarzenie 2",
            info: "Opis drugiego wydarzenia",
            startDate: Calendar.current.date(byAdding: DateComponents(day: -3), to: Date.now)!,
            imagePath: "ev2",
        ),
                   [wm, wg, pg, gg, gs, ww]
        )
        let ev3:(Event,[Station]) = (Event(
            name: "Wydarzenie 3",
            info: "Opis trzeciego wydarzenia",
            startDate: Calendar.current.date(byAdding: DateComponents(day: -7), to: Date.now)!,
            imagePath: "ev3",
        ),
                   [wm, wg, kt, os]
        )
        
        let events = [ev1, ev2, ev3]
        
        for station in stations {
            if findStation(station: station.name) == nil {
                context.insert(station)
                
                for i in 1...3 {
                    station.addStamp(stamp: Stamp(station: station, difficulty: i, imagePath: "\(station.imagePath ?? "")_s\(i)"))
                }
            }
        }
        
        for (DBLine, lineStations) in lines {
            let line = findLine(line: DBLine.name) ?? DBLine
            for station in lineStations {
                let DBStation = findStation(station: station.name)
                line.stations?.append(DBStation ?? station)
            }
        }
        
        for (DBEvent, eventStations) in events {
            let event = findEvent(event: DBEvent.name) ?? DBEvent
            for station in eventStations {
                let DBStation = findStation(station: station.name)
                event.stations?.append(DBStation ?? station)
                findStation(station: station.name)?.addStamp(stamp: Stamp(station: station, event: event, difficulty: 2, imagePath: "\(station.imagePath ?? "")_\(event.imagePath ?? "")_se"))
            }
        }
    }
    
    func findStation (station: String) -> Station? {
        let existCheck = try! context.fetch(FetchDescriptor<Station>(predicate: #Predicate<Station>{DBStation in DBStation.name == station}))
        
        return existCheck.first
    }
    
    func findLine (line: String) -> Line? {
        let existCheck = try! context.fetch(FetchDescriptor<Line>(predicate: #Predicate<Line>{DBLine in DBLine.name == line}))
        
        return existCheck.first
    }
    
    func findEvent (event: String) -> Event? {
        let existCheck = try! context.fetch(FetchDescriptor<Event>(predicate: #Predicate<Event>{DBEvent in DBEvent.name == event}))
        
        return existCheck.first
    }
}
