//
//  ContentView.swift
//  Dworcownik
//
//  Created by stud on 13/11/2025.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            Tab("Dom", systemImage: "person.crop.circle.fill") {
                HomeView()
            }
            Tab("Mapa", systemImage: "person.crop.circle.fill") {
                MapView()
            }
            Tab("W podróży", systemImage: "person.crop.circle.fill") {
                SpeedView()
            }
            Tab("Kolekcja", systemImage: "person.crop.circle.fill") {
                CollectionView()
            }
            Tab("Skanuj kod", systemImage: "person.crop.circle.fill", role: .search) {
                ContentView()
            }
        }
    }
}

#Preview {
    ContentView()
}
