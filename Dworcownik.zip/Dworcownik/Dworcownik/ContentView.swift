//
//  ContentView.swift
//  Dworcownik
//
//  Created by stud on 13/11/2025.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Text("Dzień dobry!");
            ScrollView(.horizontal) {
                HStack(spacing:-33) {
                    BigTile();
                    BigTile();
                    BigTile();
                    BigTile();
                    BigTile()
                }
                .scrollTargetLayout()
            }
            .scrollTargetBehavior(.viewAligned);
            ScrollView(.horizontal) {
                HStack(spacing:-11) {
                    SmallTile();
                    SmallTile();
                    SmallTile();
                    SmallTile();
                    SmallTile();
                }
                .scrollTargetLayout()
            }
            .scrollTargetBehavior(.viewAligned)
        }
    }
}

#Preview {
    ContentView()
}
