//
//  ContentView.swift
//  Dworcownik
//
//  Created by stud on 13/11/2025.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Text("Dzień dobry!");
            BigTile()
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
