//
//  StationStatus.swift
//  Dworcownik
//
//  Created by Krzysztof Żałobka on 02/01/2026.
//

import Foundation

var currentStation: Station? = nil
var currentStatus: Int = 0
