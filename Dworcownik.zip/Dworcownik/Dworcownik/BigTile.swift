//
//  BigTime.swift
//  Dworcownik
//
//  Created by stud on 13/11/2025.
//

import SwiftUI

struct BigTile: View {
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 34)
                .fill(.background)
                .glassEffect(in: .rect(cornerRadius: 34));
            VStack {
                UnevenRoundedRectangle(topLeadingRadius: 34, topTrailingRadius: 34)
                    .fill(.blue);
                Text("01/09 ~ 05/09");
                Text("Nazwa wydarzenia");
                Text("Opis wydarzenia");
            }
        }
        .padding([.all], 22)
        .containerRelativeFrame(.horizontal, count: 1, spacing: 0)
    }
}

#Preview {
    BigTile()
}
