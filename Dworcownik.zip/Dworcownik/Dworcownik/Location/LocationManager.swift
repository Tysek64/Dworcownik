//
//  LocationManager.swift
//  Dworcownik
//
//  Created by stud on 05/12/2025.
//


import Foundation
import CoreLocation
import QuartzCore
internal import Combine

final class LocationManager: NSObject, CLLocationManagerDelegate, ObservableObject {
    private let manager = CLLocationManager()
    private var location : (CLLocation?, CFTimeInterval?) = (nil, nil)
    private var prevLocation : (CLLocation?, CFTimeInterval?) = (nil, nil)
    
    @Published var currentSpeed: Double = 0
    var maxSpeed: Double = 0
    var currentLocation: CLLocation {
        return self.location.0 ?? CLLocation.defaultLocation
    }

    override init () {
        super.init()
        self.manager.delegate = self
        self.manager.desiredAccuracy = kCLLocationAccuracyBest
        self.manager.distanceFilter = kCLDistanceFilterNone
        self.manager.requestWhenInUseAuthorization()
        self.manager.startUpdatingLocation()
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else {
            return
        }
        
        self.prevLocation = self.location.0 != nil ? self.location : (location, CACurrentMediaTime())
        self.location = (location, CACurrentMediaTime())
        
        let coords = (self.location.0 != nil ? self.location.0 : CLLocation())!;
        let prevCoords = (self.prevLocation.0 != nil ? self.prevLocation.0: CLLocation())!;
        
        let time = (self.location.1 != nil ? self.location.1 : CFTimeInterval())!;
        let prevTime = (self.prevLocation.1 != nil ? self.prevLocation.1 : CFTimeInterval())!;

        let dist = prevCoords.distance(from: coords)
        let timeDist = time - prevTime
        
        self.currentSpeed = timeDist == 0 ? 0 : dist / timeDist * 3.6;
        self.maxSpeed = self.currentSpeed > self.maxSpeed && self.currentSpeed < 500 ? self.currentSpeed : self.maxSpeed
    }
}
