//
//  LocationManager.swift
//  Dworcownik
//
//  Created by stud on 05/12/2025.
//


import Foundation
import CoreLocation
internal import Combine

final class LocationManager: NSObject, CLLocationManagerDelegate {
    let manager = CLLocationManager()
    
    override init () {
        super.init()
    }
    
    func requestLocation() {
        manager.requestLocation()
    }
}
