//
//  CollectionView.swift
//  Dworcownik
//
//  Created by stud on 28/11/2025.
//

import SwiftUI

struct CollectionView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    CollectionView()
}
