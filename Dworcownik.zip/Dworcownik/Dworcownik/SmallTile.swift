//
//  SmallTile.swift
//  Dworcownik
//
//  Created by stud on 21/11/2025.
//

import SwiftUI

struct SmallTile: View {
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 34)
                .fill(.background)
                .glassEffect(in: .rect(cornerRadius: 34));
            VStack {
                UnevenRoundedRectangle(topLeadingRadius: 34, topTrailingRadius: 34)
                    .fill(.blue);
                Text("Nazwa przewoźnika");
                Text("Nazwa linii");
                Text("0/20");
            }
        }
        .padding([.leading], 22)
        .containerRelativeFrame(.horizontal, count: 2, spacing: 0)
    }
}

#Preview {
    SmallTile()
}
