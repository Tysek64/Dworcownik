//
//  ThreeWayTile.swift
//  Dworcownik
//
//  Created by stud on 05/12/2025.
//

import SwiftUI

struct ThreeWayTile: View {
    var first: String = ""
    var second: String = ""
    var third: String = ""
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 34)
                .fill(.background)
                .glassEffect(in: .rect(cornerRadius: 34));
            VStack {
                Text(first);
                Text(second);
                Text(third);
            }
        }
    }
}

#Preview {
    ThreeWayTile()
}
