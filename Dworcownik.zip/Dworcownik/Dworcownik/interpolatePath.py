import xml.etree.ElementTree as ET
import sys

def interpolate(a1, a2, b1, b2, num):
    diffA = (a2 - a1) / (num + 1)
    diffB = (b2 - b1) / (num + 1)
    for i in range(num + 1):
        yield {'lat': (a1 + i * diffA).__str__(), 'lon': (b1 + i * diffB).__str__()}

if __name__ == '__main__':
    if len(sys.argv) < 4:
        print('Too few arguments!')
    else: 
        filename = sys.argv[1]
        newFilename = sys.argv[3]
        numInterpolate = int(sys.argv[2])
        print("OK")

        tree = ET.parse(filename)
        root = tree.getroot()

        newTree = ET.Element(root.tag, root.attrib)

        prevLat = 0
        prevLon = 0

        currLat = 0
        currLon = 0

        for child in root:
            prevLat = currLat
            prevLon = currLon

            currLat = float(child.attrib['lat'])
            currLon = float(child.attrib['lon'])

            if prevLat != 0 and prevLon != 0:
                for coords in interpolate(prevLat, currLat, prevLon, currLon, numInterpolate):
                    print(coords)
                    _ = ET.SubElement(newTree, 'wpt', attrib=coords)

        ET.ElementTree(newTree).write(newFilename)
