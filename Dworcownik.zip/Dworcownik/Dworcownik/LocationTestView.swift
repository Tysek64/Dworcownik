//
//  LocationTestView.swift
//  Dworcownik
//
//  Created by stud on 05/12/2025.
//

import SwiftUI
import CoreLocationUI

struct LocationTestView: View {
    var locationManager: LocationManager = LocationManager()
    
    var body: some View {
        VStack {
            LocationButton {
                locationManager.requestLocation()
            }
            .frame(height: 44)
            .padding()
        }
    }
}

#Preview {
    LocationTestView()
}
