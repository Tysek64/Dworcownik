//
//  DateExtensions.swift
//  Dworcownik
//
//  Created by Krzysztof Żałobka on 24/12/2025.
//

import Foundation

extension Date {
    var dateOnly: String {
        self.formatted(date: .numeric, time: .omitted)
    }
}
