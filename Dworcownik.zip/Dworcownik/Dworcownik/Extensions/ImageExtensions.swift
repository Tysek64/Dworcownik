//
//  ImageExtensions.swift
//  Dworcownik
//
//  Created by Krzysztof Żałobka on 04/01/2026.
//

import Foundation
import SwiftUI

extension Image {
    
}
