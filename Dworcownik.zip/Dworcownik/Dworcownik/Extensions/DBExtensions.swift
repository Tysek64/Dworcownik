//
//  DBExtensions.swift
//  Dworcownik
//
//  Created by Krzysztof Żałobka on 29/12/2025.
//

import Foundation
import SwiftData

extension Station {
    // Create a static property that returns a ModelContainer
    @MainActor
    static var preview: ModelContainer {
        let container = try! ModelContainer(for: Station.self, Event.self, Line.self, Stamp.self, LineOperator.self,
                                            configurations: ModelConfiguration(isStoredInMemoryOnly: true))
        
        DBSeeder(context: container.mainContext).populateDB()
        
        return container
    }
}
