//
//  ViewExtensions.swift
//  Dworcownik
//
//  Created by Krzysztof Żałobka on 29/12/2025.
//

import Foundation
import SwiftUI

extension View {
    var rightAlign: some View {
        return HStack {
            Spacer()
            self
        }
    }
    
    var leftAlign: some View {
        return HStack {
            self
            Spacer()
        }
    }
    
    var downAlign: some View {
        return VStack {
            Spacer()
            self
        }
    }
    
    var upAlign: some View {
        return VStack {
            self
            Spacer()
        }
    }
    
    var displayBadge: some View {
        return ZStack(alignment: .topTrailing) {
            self
            Circle()
                .fill(Color.accentColor)
                .frame(width: 10, height: 10)
        }
    }
}


extension Text {
    var sectionHeading: Text {
        return self
            .foregroundStyle(.secondary)
            .fontWeight(.semibold)
    }
}

extension Image {
    var clipAndFill: some View {
        return ZStack {}
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background {
                self
                    .resizable()
                    .scaledToFill()
            }
    }
}
