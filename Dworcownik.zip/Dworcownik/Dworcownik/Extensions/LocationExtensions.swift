//
//  LocationExtensions.swift
//  Dworcownik
//
//  Created by Krzysztof Żałobka on 28/12/2025.
//

import Foundation
import MapKit

extension CLLocation {
    static var defaultLocation: CLLocation {
        return CLLocation(
            latitude: CLLocationDegrees(floatLiteral: 0),
            longitude: CLLocationDegrees(floatLiteral: 0)
        )
    }
}
