//
//  StringExtensions.swift
//  Dworcownik
//
//  Created by Krzysztof Żałobka on 02/01/2026.
//

import Foundation

extension String {
    var hexed: String {
        var result: String = "["
        for char in self.unicodeScalars {
            result.append(String(format: "%i", char.value))
            result.append(", ")
        }
        result.append("]")
        return result
    }
}
