//
//  HomeView.swift
//  Dworcownik
//
//  Created by stud on 28/11/2025.
//

import SwiftUI

struct HomeView: View {
    var body: some View {
        VStack {
            Text("Dzień dobry!");
            ScrollView(.horizontal) {
                HStack(spacing:-33) {
                    BigTile();
                    BigTile();
                    BigTile();
                    BigTile();
                    BigTile()
                }
                .scrollTargetLayout()
            }
            .scrollTargetBehavior(.viewAligned);
            ScrollView(.horizontal) {
                HStack(spacing:-16.5) {
                    SmallTile();
                    SmallTile();
                    SmallTile();
                    SmallTile();
                    SmallTile().padding([.trailing], 16.5);
                }
                .scrollTargetLayout()
            }
            .scrollTargetBehavior(.viewAligned)
            ScrollView(.horizontal) {
                HStack(spacing:-16.5) {
                    SmallTile();
                    SmallTile();
                    SmallTile();
                    SmallTile();
                    SmallTile().padding([.trailing], 16.5);
                }
                .scrollTargetLayout()
            }
            .scrollTargetBehavior(.viewAligned)
            ScrollView(.horizontal) {
                HStack(spacing:-16.5) {
                    SmallTile();
                    SmallTile();
                    SmallTile();
                    SmallTile();
                    SmallTile().padding([.trailing], 16.5);
                }
                .scrollTargetLayout()
            }
            .scrollTargetBehavior(.viewAligned)
        }
    }
}

#Preview {
    HomeView()
}
